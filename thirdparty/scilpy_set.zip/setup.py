#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup
from Cython.Distutils import Extension
from Cython.Distutils import build_ext

from glob import glob

try:
  import numpy
except ImportError as e:
    e.args += ("Try running pip install numpy",)
    raise e

try:
  import scipy
except ImportError as e:
    e.args += ("Try running pip install scipy",)
    raise e

try:
    import tractconverter as tc
except ImportError as e:
    e.args += ("Try running pip install https://github.com/MarcCote/tractconverter/archive/master.zip",)
    raise e

try:
    import matplotlib
except ImportError as e:
    e.args += ("Try running pip install matplotlib",)
    raise e


class deactivate_default_build_ext(build_ext):

    def run(self):
        print("Please use one of the custom commands to build Scilpy.\n" +
              "To see the list of commands, check the 'Extra commands' section of\n" +
              "   python setup.py --help-commands")


# Will try to build all extension modules
# Forced to be inplace for ease of import.
class build_inplace_all_ext(build_ext):

    description = "build optimized code (.pyx files) " +\
                  "(compile/link inplace)"

    def finalize_options(self):
        # Force inplace building for ease of importation
        self.inplace = True
        build_ext.finalize_options(self)


ext_modules = [
    Extension('scilpy.tractanalysis.robust_streamlines_metrics',
              ['scilpy/tractanalysis/robust_streamlines_metrics.pyx'],
              include_dirs=[numpy.get_include()]),
    Extension('scilpy.tractanalysis.uncompress',
              ['scilpy/tractanalysis/uncompress.pyx'],
              include_dirs=[numpy.get_include()]),
    Extension('scilpy.tractanalysis.grid_intersections',
              ['scilpy/tractanalysis/grid_intersections.pyx'],
              include_dirs=[numpy.get_include()]),
    Extension('scilpy.tractanalysis.compute_tract_counts_map',
              ['scilpy/tractanalysis/compute_tract_counts_map.pyx'],
              include_dirs=[numpy.get_include()]),
    Extension('scilpy.image.toolbox',
              ['scilpy/image/toolbox.pyx'],
              include_dirs=[numpy.get_include()])
]

dependencies = ['dipy', 'imageio', 'mne', 'nibabel', 'nipype', 'Pillow', 'six']

setup(name='scilpy', version='0.1', description='A neuroimaging toolbox',
      url='http://bitbucket.org/sciludes/scilpy', ext_modules=ext_modules,
      author='The SCIL team', author_email='scil.udes@gmail.com',
      scripts=glob('scripts/*.py'), test_suite='scripts.tests',
      cmdclass={'build_ext': deactivate_default_build_ext,
                'build_all': build_inplace_all_ext})
