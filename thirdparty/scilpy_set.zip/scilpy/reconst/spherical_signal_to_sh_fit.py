# -*- coding: utf-8 -*-

from dipy.core.geometry import cart2sphere
from dipy.reconst.multi_voxel import multi_voxel_fit
from dipy.reconst.shm import (SphHarmModel, SphHarmFit, lazy_index,
                              smooth_pinv, sph_harm_lookup)
import numpy as np


class SphericalSignalToSHFit(SphHarmModel):
    """Implementation of a direct fit of Spherical Harmonics (SH) coefficients
       to a signal on a sphere. No underlying model of signal distribution is
       used.

       This can be used to find the best SH representation of a specific
       signal.

       Uses the basic Dipy basis, which is the one defined in Descoteaux.
    """
    def __init__(self, gtab, sh_order, smooth=0.006, basis_type=None):
        """Creates a model that can be used to fit the diffusion data

        Arguments
        ---------
        gtab : GradientTable
            Diffusion gradients used to acquire data
        sh_order : even int >= 0
            the spherical harmonic order of the model
        smooth : float between 0 and 1, optional
            The regularization parameter of the model
        basis_type : {None, 'tournier07', 'descoteaux07'}
            ``None`` for the default dipy basis,
            ``tournier07`` for the MRtrix basis, and
            ``descoteaux07`` for the Descoteaux basis
            (default ``None``).
        """
        SphHarmModel.__init__(self, gtab)
        self._where_b0s = lazy_index(gtab.b0s_mask)
        self._where_dwi = lazy_index(~gtab.b0s_mask)
        x, y, z = gtab.gradients[self._where_dwi].T
        r, theta, phi = cart2sphere(x, y, z)

        sph_harm_basis = sph_harm_lookup.get(basis_type)

        if sph_harm_basis is None:
            raise ValueError("Invalid basis name.")

        B, m, n = sph_harm_basis(sh_order, theta[:, None], phi[:, None])
        L = -n * (n + 1)
        self.sh_order = sh_order
        self.B = B
        self.m = m
        self.n = n
        self._set_fit_matrix(B, L, smooth)

    def _set_fit_matrix(self, B, L, smooth):
        invB = smooth_pinv(B, np.sqrt(smooth) * L)
        self._fit_matrix = invB

    def _get_shm_coef(self, data, mask=None):
        """Returns the coefficients of the model"""
        return np.dot(data[..., self._where_dwi], self._fit_matrix.T)

    @multi_voxel_fit
    def fit(self, data, mask=None):
        """Fits the model to diffusion data and returns the model fit"""
        # Compute coefficients using abstract method
        coef = self._get_shm_coef(data)

        # Apply the mask to the coefficients
        if mask is not None:
            mask = np.asarray(mask, dtype=bool)
            coef *= mask[..., None]
        return SphHarmFit(self, coef, mask)
