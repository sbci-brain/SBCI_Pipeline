from __future__ import division

from fury import window, actor
import numpy as np

from scilpy.surface.seed import get_vertices_from_seeds, get_normals_from_seeds

# Optionnal package
from dipy.utils.optpkg import optional_package
trimeshpy, _, _ = optional_package('trimeshpy')


def visualize_mesh(mesh):
    vtk_mesh = trimeshpy.TriMesh_Vtk(mesh.get_triangles(), mesh.get_vertices())
    vtk_mesh.display("Scilpy + TriMeshPy visualization")


def visualize_mesh_with_seeds(mesh, tri_idx, tri_coord,
                              normals=True, normals_size=0.5):
    seeds_vts = get_vertices_from_seeds(mesh, tri_idx, tri_coord)

    scene = window.Scene()
    scene.add(mesh.get_vtk_actor())
    scene.add(actor.dots(seeds_vts, color=(0, 1, 0), dot_size=3))

    if normals is not False:
        if normals is True:
            normals = get_normals_from_seeds(mesh, tri_idx, tri_coord)

        lines1 = np.tile(seeds_vts[:, np.newaxis, :], (1, 2, 1))
        lines2 = np.tile(seeds_vts[:, np.newaxis, :], (1, 2, 1))
        lines1[:, 0] -= normals * normals_size
        lines2[:, 1] += normals * normals_size

        scene.add(actor.line(lines1, colors=(1, 0, 0)))
        scene.add(actor.line(lines2, colors=(0, 0, 1)))

    window.show(scene, size=(1024, 800))

