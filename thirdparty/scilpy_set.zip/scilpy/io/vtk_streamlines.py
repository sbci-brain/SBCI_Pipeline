#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division

from dipy.tracking.streamline import transform_streamlines
import numpy as np

from dipy.utils.optpkg import optional_package
vtk, have_vtk, setup_module = optional_package('vtk')
ns, have_ns, setup_module = optional_package('vtk.util.numpy_support')

def set_input(vtk_object, current_input):
    if isinstance(current_input, vtk.vtkPolyData):
        if vtk.VTK_MAJOR_VERSION <= 5:
            vtk_object.SetInput(current_input)
        else:
            vtk_object.SetInputData(current_input)
    elif isinstance(input, vtk.vtkAlgorithmOutput):
        vtk_object.SetInputConnection(current_input)

    vtk_object.Update()

    return vtk_object


def lines_to_vtk_polydata(lines):
    # LPS (mm) to RAS (mm)
    to_RAS = np.eye(4)
    to_RAS[0, 0] = -1
    to_RAS[1, 1] = -1

    # Get the 3d points_array
    nb_lines = len(lines)
    points_array = np.vstack(transform_streamlines(lines, to_RAS))

    # Get lines_array in vtk input format
    lines_array = []
    current_position = 0
    for i in xrange(nb_lines):
        current_len = len(lines[i])

        end_position = current_position + current_len
        lines_array.append(current_len)
        lines_array.extend(range(current_position, end_position))
        current_position = end_position

    # Set Points to vtk array format
    vtk_points = vtk.vtkPoints()
    vtk_points.SetData(
        ns.numpy_to_vtk(points_array.astype(np.float32), deep=True))

    # Set Lines to vtk array format
    vtk_lines = vtk.vtkCellArray()
    vtk_lines.SetNumberOfCells(nb_lines)
    vtk_lines.GetData().DeepCopy(
        ns.numpy_to_vtk(np.array(lines_array), deep=True))

    # Create the poly_data
    poly_data = vtk.vtkPolyData()
    poly_data.SetPoints(vtk_points)
    poly_data.SetLines(vtk_lines)

    return poly_data


def save_vtk_streamlines(streamlines, filename, binary=False):
    polydata = lines_to_vtk_polydata(streamlines)
    writer = vtk.vtkPolyDataWriter()
    writer.SetFileName(filename)
    writer = set_input(writer, polydata)

    if binary:
        writer.SetFileTypeToBinary()

    writer.Update()
    writer.Write()


def load_vtk_streamlines(filename):
    reader = vtk.vtkPolyDataReader()
    reader.SetFileName(filename)
    reader.Update()
    polydata = reader.GetOutput()

    lines_vertices = ns.vtk_to_numpy(polydata.GetPoints().GetData())
    lines_idx = ns.vtk_to_numpy(polydata.GetLines().GetData())

    lines = []
    current_idx = 0
    while current_idx < len(lines_idx):
        line_len = lines_idx[current_idx]

        next_idx = current_idx + line_len + 1
        line_range = lines_idx[current_idx + 1: next_idx]

        lines += [lines_vertices[line_range]]
        current_idx = next_idx

    # LPS (mm) to RAS (mm)
    to_RAS = np.eye(4)
    to_RAS[0, 0] = -1
    to_RAS[1, 1] = -1

    return transform_streamlines(lines, to_RAS)
