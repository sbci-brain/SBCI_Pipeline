#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division
from itertools import islice
import os
import six

import nibabel as nib
from nibabel.streamlines import (
    TckFile,
    TrkFile,
    detect_format,
    Tractogram,
    Field,
    save)
from nibabel.streamlines.trk import (get_affine_rasmm_to_trackvis,
                                     get_affine_trackvis_to_rasmm)
import numpy as np
from numpy import linalg
from numpy.lib.index_tricks import c_
import tractconverter as tc

from scilpy.io.utils import create_header_from_anat


def scilpy_supports(streamlines_filename):
    if not tc.TCK._check(streamlines_filename) and\
       not tc.TRK._check(streamlines_filename):
        return False

    return True


def check_tracts_support(parser, path, tp):
    # Check left in place to make sure that this is checked
    # even if the next check (TCK or TRK) is removed at one point.
    if not tc.is_supported(path):
        parser.error('Format of "{}" not supported.'.format(path))

    if not scilpy_supports(path):
        parser.error(
            'The format of the input tracts is not currently supported by '
            'this script, because the TC space is undefined.\nPlease see '
            'jean-christophe.houde@usherbrooke.ca for solutions.')

    if tp is None and is_trk(path):
        parser.error(
            'When providing a trk file, please also set the --tp argument.')


def check_tracts_same_format(parser, tracts1, tracts2):
    if not os.path.splitext(tracts1)[1] == os.path.splitext(tracts2)[1]:
        parser.error('Input and output tracts file must use the same format.')


def is_trk(streamlines_filename):
    tracts_format = tc.detect_format(streamlines_filename)
    tracts_file = tracts_format(streamlines_filename)

    if isinstance(tracts_file, tc.formats.trk.TRK):
        return True

    return False


def ichunk(sequence, n):
    """ Yield successive n-sized chunks from sequence. """
    sequence = iter(sequence)
    chunk = list(islice(sequence, n))
    while len(chunk) > 0:
        yield chunk
        chunk = list(islice(sequence, n))


def load_tracts_over_grid(tract_fname, ref_anat_fname, start_at_corner=True,
                          tract_producer=None):
    tracts_format = tc.detect_format(tract_fname)
    tracts_file = tracts_format(tract_fname)

    # Get information on the supporting anatomy
    ref_img = nib.load(ref_anat_fname)

    index_to_world_affine = ref_img.get_header().get_best_affine()

    #  TODO
    if isinstance(tracts_file, tc.formats.vtk.VTK):
        raise IOError('VTK tracts not currently supported')

    # Transposed for efficient computations later on.
    index_to_world_affine = index_to_world_affine.T.astype('<f4')
    world_to_index_affine = linalg.inv(index_to_world_affine)

    # Load tracts
    if isinstance(tracts_file, tc.formats.tck.TCK):
        if start_at_corner:
            shift = 0.5
        else:
            shift = 0.0

        for s in tracts_file:
            transformed_s = np.dot(c_[s, np.ones([s.shape[0], 1],
                                                 dtype='<f4')],
                                   world_to_index_affine)[:, :-1] + shift
            yield transformed_s
    elif isinstance(tracts_file, tc.formats.trk.TRK):
        if tract_producer is None:
            raise ValueError('Cannot robustly load TRKs without the '
                             'tract_producer argument.')

        # Use nib.trackvis to read directly in correct space
        # TODO this should be made more robust, using
        # all fields in header.
        # Currently, load in rasmm space, and then bring back to LPS vox
        try:
            streamlines, _ = nib.trackvis.read(tract_fname,
                                               as_generator=True,
                                               points_space='rasmm')
        except nib.trackvis.HeaderError as er:
            raise ValueError(
                "\n------ ERROR ------\n\n" +
                "TrackVis header is malformed or incomplete.\n" +
                "Please make sure all fields are correctly set.\n\n" +
                "The error message reported by Nibabel was:\n" +
                str(er))

        # Producer: scilpy means that streamlines respect the nifti standard
        # Producer: trackvis means that (0,0,0) is the corner of the voxel
        if start_at_corner:
            if tract_producer == "scilpy":
                shift = 0.5
            elif tract_producer == "trackvis":
                shift = 0.0
        else:
            if tract_producer == "scilpy":
                shift = 0.0
            elif tract_producer == "trackvis":
                shift = -0.5

        for s in streamlines:
            transformed_s = np.dot(
                c_[s[0], np.ones([s[0].shape[0], 1], dtype='<f4')],
                world_to_index_affine)[:, :-1] + shift
            yield transformed_s


# Note: this function is part of the incoming transition of the whole
# library to using exclusively the streamlines API. There are still calls to
# the TractConverter since tck support in not currently included in an
# official Nibabel release.
def load_tracts_over_grid_transition(tract_fname,
                                     ref_anat_fname,
                                     start_at_corner=True,
                                     tract_producer=None):
    tracts_format = tc.detect_format(tract_fname)
    tracts_file = tracts_format(tract_fname)

    # TODO
    if isinstance(tracts_file, tc.formats.vtk.VTK):
        raise IOError('VTK tracts not currently supported')

    # Load tracts
    if isinstance(tracts_file, tc.formats.tck.TCK):
        # Get information on the supporting anatomy
        ref_img = nib.load(ref_anat_fname)
        index_to_world_affine = ref_img.get_header().get_best_affine()

        # Transposed for efficient computations later on.
        index_to_world_affine = index_to_world_affine.T.astype('<f4')
        world_to_index_affine = linalg.inv(index_to_world_affine)

        if start_at_corner:
            shift = 0.5
        else:
            shift = 0.0

        strls = []

        for s in tracts_file:
            # We use c_ to easily transform the 3D streamline to a
            # 4D object to allow using the dot product with uniform
            # coordinates. Basically, this adds a 1 at the end of
            # each point, to be able to directly perform the dot product.
            transformed_s = np.dot(c_[s, np.ones([s.shape[0], 1],
                                                 dtype='<f4')],
                                   world_to_index_affine)[:, :-1] + shift
            strls.append(transformed_s)

        return strls
    elif isinstance(tracts_file, tc.formats.trk.TRK):
        if tract_producer is None:
            raise ValueError('Cannot robustly load TRKs without the '
                             'tract_producer argument.')

        streamlines = load_trk_in_voxel_space(tract_fname, ref_anat_fname)

        # The previous call returns the streamlines in voxel space,
        # corner-aligned. Check if we need to shift them back.

        # Producer: scilpy means that streamlines respect the nifti standard
        # Producer: trackvis means that (0,0,0) is the corner of the voxel
        if start_at_corner:
            if tract_producer == "scilpy":
                shift = 0.5
            elif tract_producer == "trackvis":
                shift = 0.0
        else:
            if tract_producer == "scilpy":
                shift = 0.0
            elif tract_producer == "trackvis":
                shift = -0.5

        streamlines._data += shift

        return streamlines


def load_trk_in_voxel_space(trk_file, anat=None, grid_res=None,
                            raise_on_empty=True):
    """
    Load streamlines in voxel space, corner aligned

    :param trk_file: path or nibabel object
    :param anat: path or nibabel image (optional)
    :param grid_res: specify the grid resolution (3,) (optional)
    :return: NiBabel tractogram with streamlines loaded in voxel space
    """
    if isinstance(trk_file, six.string_types):
        trk_file = nib.streamlines.load(trk_file)

    if trk_file.header[Field.NB_STREAMLINES] == 0 and raise_on_empty:
        raise Exception("The bundle contains no streamline")

    if anat and grid_res:
        raise Exception("Parameters anat and grid_res cannot be used together")

    if anat:
        if isinstance(anat, six.string_types):
            anat = nib.load(anat)
        spacing = anat.header['pixdim'][1:4]
    elif grid_res:
        spacing = grid_res
    else:
        spacing = trk_file.header[Field.VOXEL_SIZES]

    affine_to_voxmm = get_affine_rasmm_to_trackvis(trk_file.header)
    tracto = trk_file.tractogram
    tracto.apply_affine(affine_to_voxmm)
    streamlines = tracto.streamlines

    if trk_file.header[Field.NB_STREAMLINES] > 0:
        streamlines._data /= spacing
    return streamlines


def save_trk_from_voxel_space(streamlines, out_name,
                              ref_trk_file=None, anat=None):
    """
    Save streamlines from voxel space, corner aligned

    :param streamlines: list of all streamlines
    :param streamlines: filename for output
    :param streamlines: reference trk nibabel object or filename (optional)
    :param anat: path or nibabel image (optional)
    """
    if ref_trk_file and anat:
        raise IOError(
            "Parameters ref_trk_file and anat cannot be used together")

    if ref_trk_file or anat:
        if ref_trk_file:
            if isinstance(ref_trk_file, six.string_types):
                ref_trk_file = nib.streamlines.load(
                    ref_trk_file, lazy_load=True)
            header = ref_trk_file.header
        else:
            if isinstance(anat, six.string_types):
                anat = nib.load(anat)
            header = create_header_from_anat(anat)
        header[Field.NB_STREAMLINES] = len(streamlines)
    else:
        raise IOError("At least one reference file is needed")

    spacing = header[Field.VOXEL_SIZES]
    voxmm_to_rasmm = get_affine_trackvis_to_rasmm(header)
    tracto = Tractogram(streamlines=streamlines,
                        affine_to_rasmm=voxmm_to_rasmm)

    if header[Field.NB_STREAMLINES] > 0:
        tracto.streamlines._data *= spacing
    tracto.apply_affine(voxmm_to_rasmm)

    nib.streamlines.save(tracto, out_name, header=header)


def save_streamlines(streamlines, ref_filename, output_filename, seeds=[]):
    """
    Parameters
    ----------
    streamlines: List of numpy.arrays of numpy.arrays
        The actual streamlines
    ref_filename: string
        File to load the reference affine from
    output_filename: string
        Location of the streamlines file
    seeds: List of numpy.arrays
        Seeds to save alongside the streamlines
        Will be an empty array if unwanted

    Returns
    -------

    """
    tracts_format = detect_format(output_filename)
    if tracts_format not in [TrkFile, TckFile]:
        raise ValueError("Invalid output streamline file format " +
                         "(must be trk or tck): {0}".format(output_filename))
    # Create the affine to go from voxmm (expected space) to
    # ras+ mm.
    ref_file = nib.load(ref_filename)

    # Use this to remove the scaling component from the reference affine.
    unscaling_matrix = np.eye(4)
    unscaling_matrix[range(3), range(3)] = 1. / np.array(
        ref_file.header.get_zooms())
    voxmm_to_rasmm = np.dot(ref_file.affine, unscaling_matrix)

    tractogram = Tractogram(streamlines, affine_to_rasmm=voxmm_to_rasmm)

    if seeds is not None and len(seeds) > 0:
        transformed_seeds = nib.affines.apply_affine(voxmm_to_rasmm, seeds)
        tractogram.data_per_streamline['seeds'] = transformed_seeds

    header = create_header_from_anat(ref_file, tracts_format)

    save(tractogram, output_filename, header=header)
