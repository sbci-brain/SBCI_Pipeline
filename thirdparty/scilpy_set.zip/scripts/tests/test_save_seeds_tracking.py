#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" The first three tests are to make sure the three "cases" in
localTracking.py are handled so that seeds are kept. The following
test is to make sure seeds are not kept when you don't want them.
"""

import os
import unittest
import numpy as np

from nibabel.streamlines import load

from _BaseTest import BaseTest
from scripts.scil_compute_tracking import main


class TestSaveSeeds(BaseTest):

    def set_up_get_files(self):
        fodf_path = self.fetch('fodf.nii.gz')
        interface_path = self.fetch('gm_mask_small.nii.gz')
        mask_path = self.fetch('wm_mask_binary.nii.gz')
        tracts_path = os.path.join(self._tmp_dir, 'output.trk')

        return fodf_path, interface_path, mask_path, tracts_path

    def test_compute_tracking_seeds_zero_ns_one_process(self):
        """ Test that scil_compute_tracking keeps seeds
        when no seeds per voxel is specified and one processes is used
        """
        fodf_path, interface_path, mask_path, tracts_path = \
            self.set_up_get_files()
        self.call(main, fodf_path, interface_path, mask_path, tracts_path,
                  '--save_seeds', ns=0, processes=1, sh_basis='descoteaux07')

        seeds = load(tracts_path).tractogram.data_per_streamline['seeds']
        self.assertTrue(len(seeds) > 0, 'Not enough seeds')

    def test_compute_tracking_seeds_zero_ns_ten_process(self):
        fodf_path, interface_path, mask_path, tracts_path = \
            self.set_up_get_files()

        self.call(main, fodf_path,
                  interface_path, mask_path, tracts_path,
                  '--save_seeds', ns=0, processes=3, sh_basis='descoteaux07')

        seeds = load(tracts_path).tractogram.data_per_streamline['seeds']
        self.assertTrue(len(seeds) > 0,
                        'Not enough seeds')

    def test_compute_tracking_seeds_one_ns_one_process(self):
        fodf_path, interface_path, mask_path, tracts_path = \
            self.set_up_get_files()

        self.call(main, fodf_path,
                  interface_path, mask_path, tracts_path,
                  '--save_seeds', ns=1, processes=1, sh_basis='descoteaux07')

        seeds = load(tracts_path).tractogram.data_per_streamline['seeds']
        self.assertTrue(len(seeds) > 0,
                        'Not enough seeds')

    def test_compute_tracking_dont_keep_seeds_if_false(self):
        fodf_path, interface_path, mask_path, tracts_path = \
            self.set_up_get_files()

        self.call(main, fodf_path,
                  interface_path, mask_path, tracts_path,
                  ns=0, processes=3, sh_basis='descoteaux07')
        seeds = load(tracts_path).tractogram.data_per_streamline['seeds']
        self.assertTrue(not isinstance(seeds, list),
                        'seeds shouldn\'t be present')


if __name__ == '__main__':
    unittest.main()
