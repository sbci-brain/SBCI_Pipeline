#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import os
import unittest

from _BaseTest import BaseTest, RedirectStdOut

from scripts.scil_fit_dwi_to_sh import main


class TestFitDWIToSH(BaseTest):

    def test(self):
        dwi_path = self.fetch('dwi_nlm.nii.gz')
        bvals_path = self.fetch('bval')
        bvecs_path = self.fetch('bvec')

        output_sh_path = os.path.join(self._tmp_dir, 'pure_sh.nii.gz')

        self.call(main, dwi_path, bvals_path, bvecs_path, output_sh_path)

        self.compare_images(output_sh_path,
                            self.fetch('GT/sh_fit', 'pure_sh.nii.gz'),
                            almost_equal=True)


if __name__ == '__main__':
    unittest.main()
