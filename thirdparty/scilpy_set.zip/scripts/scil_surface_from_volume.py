#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import logging
import numpy as np
import nibabel as nib
from scipy.ndimage import morphology, binary_fill_holes, label

from scilpy.io.utils import (
    add_overwrite_arg, assert_inputs_exist, assert_outputs_exists)

from dipy.utils.optpkg import optional_package
vtk_u, _, _ = optional_package('trimeshpy.vtk_util')
trimesh_vtk, _, _ = optional_package('trimeshpy.trimesh_vtk')
mcubes, _, _ = optional_package('mcubes')  # github.com/pmneila/PyMCubes


DESCRIPTION = """
Script to convert segmented volume to a surface with marching cube'
example : use wmparc.a2009s.nii.gz with some aseg.stats indices
> python se_vol2surf.py s1a1/mask/S1-A1_wmparc.a2009s.nii.gz\\
    -v -index 16  --vox2vtk -opening 2 -smooth 2
"""

EPILOG = """
References:
[1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
    Surface-enhanced tractography (SET). NeuroImage.
"""


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument('volume', help='input volume/mask')

    p.add_argument('out_surface',
                   help='output surface (.vtk)')

    # masking (label operation)
    p.add_argument('--mask_volume',
                   help='mask some volume region')

    p.add_argument('--index', type=int, nargs='+',
                   help='mask only the selected label')
    p.add_argument('--all', action='store_true',
                   help='use all label (> zero) as mask')

    p.add_argument('--value', type=float, default=0.5,
                   help='threshold value')

    p.add_argument('--smooth', type=float, default=0.0,
                   help='smoothing size with 1 implicit step')
    p.add_argument('--erosion', type=int, default=0,
                   help='erosion iterations')
    p.add_argument('--dilation', type=int, default=0,
                   help='dilation iterations')
    p.add_argument('--opening', type=int, default=0,
                   help='opening iterations')
    p.add_argument('--closing', type=int, default=0,
                   help='closing iterations')

    p.add_argument('--max_label', action='store_true',
                   help='label all group of voxel and take the biggest')

    p.add_argument('--fill', action='store_true',
                   help='fill holes in the image')

    p.add_argument('--vox2vtk', action='store_true',
                   help='transfo to vox2vtk')

    add_overwrite_arg(p)
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    assert_inputs_exist(parser, required=[args.volume])
    assert_outputs_exists(parser, args, args.out_surface)

    # Load volume
    volume_file = args.volume
    volume_nib = nib.load(volume_file)
    volume = volume_nib.get_data()

    # get data mask from index and volume
    if args.index is not None:
        mask = np.zeros_like(volume)
        for index in args.index:
            mask = np.logical_or(mask, volume == index)
    else:
        mask = np.copy(volume_nib.get_data())
        if args.all:
            mask[mask > 0] = 1

    # Basic morphology
    if args.erosion > 0:
        mask = morphology.binary_erosion(mask, iterations=args.erosion)
    if args.dilation > 0:
        mask = morphology.binary_dilation(mask, iterations=args.dilation)
    if args.opening > 0:
        mask = morphology.binary_opening(mask, iterations=args.opening)
    if args.closing > 0:
        mask = morphology.binary_closing(mask, iterations=args.closing)

    # Label fill
    if args.max_label:
        label_objects, nb_labels = label(mask)
        sizes = np.bincount(label_objects.ravel())
        sizes[0] = 0  # ignore zero voxels
        max_label = np.argmax(sizes)
        max_mask = (label_objects == max_label)
        mask = max_mask

    if args.fill:
        mask = binary_fill_holes(mask)

    # Extract marching cube surface from mask
    vertices, triangles = mcubes.marching_cubes(mask, args.value)

    # Generate mesh
    mesh = trimesh_vtk.TriMesh_Vtk(triangles.astype(np.int), vertices)

    # Transformation based on the Nifti affine
    if args.vox2vtk:
        mesh.set_vertices(vtk_u.vox_to_vtk(mesh.get_vertices(), volume_nib))

    # Smooth
    if args.smooth > 0:
        new_vertices = mesh.laplacian_smooth(1, args.smooth,
                                             l2_dist_weighted=False,
                                             area_weighted=False,
                                             backward_step=True)
        mesh.set_vertices(new_vertices)

    mesh.save(args.out_surface)


if __name__ == "__main__":
    main()
