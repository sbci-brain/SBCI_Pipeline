#! /usr/bin/env python

from __future__ import print_function

DESCRIPTION = """
Previously, transform noisy rician/non central chi signals into
gaussian distributed signals.

This script doesn't do anything anymore.

You can use the nlsam/scripts/nlsam_denoising script, 
which is available at
https://github.com/samuelstjean/nlsam
You can get back the same behavior by using
--save_stab, --save_sigma and --no_denoising at the same time.
"""


def main():
    print(DESCRIPTION)


if __name__ == "__main__":
    main()
