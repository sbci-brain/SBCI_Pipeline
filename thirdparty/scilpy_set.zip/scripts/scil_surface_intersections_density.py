#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division, print_function

import argparse
import logging

from fury import window, actor
import numpy as np

from scilpy.io.surface import load_mesh_from_file
from scilpy.io.utils import assert_inputs_exist
import scilpy.surface.intersection as stools

DESCRIPTION = """
Script to compute density map from surface intersections (per triangle, or per lable)
generated from 'scil_surface_tractogram_filtering.py'.

The resulting density SUM to the number of given
intersections (streamlines), if no intersected indices are removed.
"""

EPILOG = """
References:
[1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
    Surface-enhanced tractography (SET). NeuroImage.
"""

REMOVED_INDICES = np.iinfo(np.int32).max


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('surface',
                   help='Input surface, for triangles (Freesurfer or supported by VTK)')

    p.add_argument('intersections',
                   help="Surface intersections file (.npz) (.txt)")

    p.add_argument('output_surface_density',
                   help="Surface density per triangle map (.npy)")

    p.add_argument('--normalize_l1_to', type=int,
                   help="Normalized the density; to sum to the given number")

    p.add_argument('--binarize', type=float,
                   help="binarize surface density with the given threshold")
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    assert_inputs_exist(parser,
                        required=[args.surface, args.intersections])

    surf_ids0, tri_ids0, vts_0, surf_ids1, tri_ids1, vts_1 \
        = stools.load_surface_intersections(args.intersections)

    # surf_ids = np.concatenate([surf_ids0, surf_ids1])
    tri_ids = np.concatenate([tri_ids0, tri_ids1])

    # Preparing mesh, with label id
    mesh = load_mesh_from_file(args.surface)

    nb_triangles = mesh.get_nb_triangles()

    tri_counts = np.bincount(tri_ids, minlength=nb_triangles)

    if args.normalize_l1_to:
        tri_counts = tri_counts.astype(np.float)
        tri_counts *= args.normalize_l1_to/tri_counts.sum()

    if args.binarize:
        tri_counts = tri_counts >= args.binarize
        # tri_area = mesh.triangles_area()

    np.save(args.output_surface_density, tri_counts)


if __name__ == "__main__":
    main()
