#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division, print_function

import argparse
import logging

import numpy as np

from scilpy.io.surface import load_mesh_from_file
from scilpy.io.utils import assert_inputs_exist
from scilpy.surface.seed import get_trilinear_coordinates_from_vertices
import scilpy.surface.intersection as stools

DESCRIPTION = """
Script to compute connectivity matrix from surface intersections
generated from 'scil_surface_tractogram_filtering.py'.

The resulting connectivity matrix SUM to the number of given
intersections (streamlines), if no intersected indices are removed.
"""

EPILOG = """
References:
[1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
    Surface-enhanced tractography (SET). NeuroImage.
"""


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('surface',
                   help='Input surface (Freesurfer or supported by VTK)')

    p.add_argument('surface_intersections',
                   help="Surface intersections file (.npz) (.txt)")

    p.add_argument('labels', help='Input labels per vertices (.annot,.npy)\n'
                                  ' same order as intersections_info')

    p.add_argument('output_connectivity_matrix',
                   help="Surface intersections file (.npy)")
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    assert_inputs_exist(parser, required=([args.surface_intersections,
                                           args.surface, args.labels]))

    surf_ids0, tri_ids0, pts0, surf_ids1, tri_ids1, pts1 \
        = stools.load_surface_intersections(args.surface_intersections)

    # load mesh and labels
    mesh = load_mesh_from_file(args.surface)
    vts_label = np.load(args.labels)

    # Get number of label with and without the filler
    nb_label = np.max(vts_label[vts_label != stools.REMOVED_INDICES]) + 1

    vts_label[vts_label == stools.REMOVED_INDICES] = nb_label
    nb_label_with_filler = nb_label + 1
    # Compute connectivity matrix
    coo_shape = (nb_label_with_filler, nb_label_with_filler)

    mesh_tri = mesh.get_triangles()
    mesh_vts = mesh.get_vertices()

    tri_a = mesh_tri[tri_ids0]
    tri_b = mesh_tri[tri_ids1]

    tri_vts_a = mesh_vts[tri_a]
    tri_vts_b = mesh_vts[tri_b]

    # Weight of the 3 vertices of each triangle
    tri_coord_a = np.squeeze(
        get_trilinear_coordinates_from_vertices(
            tri_vts_a,
            pts0,
            force_inside=True))
    # Labels of each of those vertices

    # Weight of the 3 vertices of each triangle
    tri_coord_b = np.squeeze(
        get_trilinear_coordinates_from_vertices(
            tri_vts_b,
            pts1,
            force_inside=True))

    if not np.allclose(tri_coord_a.sum(-1), 1.0) or not np.allclose(tri_coord_b.sum(-1), 1.0):
        logging.warning("Some barycentric coordinates does not sum to 1")

    # Labels of each of those vertices
    label_a = vts_label[tri_a]
    label_b = vts_label[tri_b]

    row = np.tile(label_a, (3, 1)).T.flatten()
    col = np.tile(label_b, (1, 3)).T.flatten()
    indices_1d = np.ravel_multi_index([row, col], dims=coo_shape)

    # Outer product and flatten for weights list
    w = (tri_coord_a[:, :, np.newaxis] * tri_coord_b[:, np.newaxis, :]).flatten()

    # construct the connectivity matrix by summing weights
    bins = np.bincount(indices_1d, minlength=np.prod(coo_shape), weights=w)
    coo = bins.reshape(coo_shape)

    # remove the last label /filler (from invalid indices)
    coo = coo[:-1, :-1]

    np.save(args.output_connectivity_matrix, coo)


if __name__ == "__main__":
    main()
