#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import os

import nibabel as nib
import numpy as np

from scilpy.io.utils import create_header_from_anat
from scilpy.io.vtk_streamlines import save_vtk_streamlines, load_vtk_streamlines
from scilpy.io.utils import add_overwrite_arg, assert_inputs_exist, assert_outputs_exists

DESCRIPTION = """
Conversion of '.tck', '.trk', '.fib', '.vtk' files using updated file format
standard. TRK file always needs a reference file, a NIFTI, for conversion.
The FIB file format is in fact a VTK, MITK Diffusion supports it.
"""


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('in_tractogram', metavar='IN_TRACTOGRAM',
                   help='Tractogram filename. Format must be \n'
                        'readable by the Nibabel.')

    p.add_argument('output_name', metavar='OUTPUT_NAME',
                   help='Output filename. Format must be \n'
                        'writable by Nibabel.')

    p.add_argument('--reference',
                   help='Reference file to create .trk header, must be .nii.gz')

    add_overwrite_arg(p)

    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()

    assert_inputs_exist(parser, [args.in_tractogram], [args.reference])

    in_extension = os.path.splitext(args.in_tractogram)[1]
    out_extension = os.path.splitext(args.output_name)[1]

    # Verification of file format and reference file
    if in_extension not in ['.tck', '.trk', '.fib', '.vtk']:
        parser.error('Input tractogram file format not supported')

    if out_extension not in ['.tck', '.trk', '.fib', '.vtk']:
        parser.error('Output tractogram file format not supported')

    if in_extension == out_extension:
        parser.error('Input and output cannot be of the same file format')

    if out_extension == '.trk' and not args.reference:
        parser.error('Reference file needed for TRK file format')

    assert_outputs_exists(parser, args, args.output_name)

    if in_extension in ['.tck', '.trk']:
        input_tractogram = nib.streamlines.load(args.in_tractogram)
        streamlines = input_tractogram.streamlines
    elif in_extension in ['.fib', '.vtk']:
        streamlines = load_vtk_streamlines(args.in_tractogram)

    if out_extension in ['.tck', '.trk']:
        tractogram_type = nib.streamlines.detect_format(args.output_name)

        if out_extension == '.trk':
            header = create_header_from_anat(args.reference)
        elif out_extension == '.tck':
            header = tractogram_type.create_empty_header()

        new_tractogram = nib.streamlines.Tractogram(streamlines,
                                                    affine_to_rasmm=np.eye(4))
        fileobj = tractogram_type(new_tractogram,
                                  header=header)
        nib.streamlines.save(fileobj, args.output_name)

    elif out_extension in ['.fib', '.vtk']:
        save_vtk_streamlines(streamlines, args.output_name, binary=True)


if __name__ == "__main__":
    main()
