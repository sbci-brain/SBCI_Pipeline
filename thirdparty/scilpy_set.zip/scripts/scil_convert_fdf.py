#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import os

from scilpy.io.varian_fdf import load_fdf, save_babel

DESCRIPTION = """
   Converts a Varian FDF file or directory to a nifti file.
   If the procpar contains diffusion information, it will be saved as bval and
   bvec in the same folder as the output file.
   """

def build_arg_parser():

    p = argparse.\
        ArgumentParser(description=DESCRIPTION,
                       formatter_class=argparse.RawDescriptionHelpFormatter)

    p.add_argument('in_path', action='store', type=str,
                   help='Path to the FDF file or folder to convert.')
    p.add_argument('out_path', action='store', type=str,
                   help='Path to the nifti file to write on disk.')
    p.add_argument('--bval', action='store', type=str, default='',
                   help='Path to the bval file to write on disk.')
    p.add_argument('--bvec', action='store', type=str, default='',
                   help='Path to the bvec file to write on disk.')
    p.add_argument('-f', action='store_true', dest="force",
                   help='force overwriting files, if they exist.')
    return p


def main():
    parser = build_arg_parser()
    args = parser.parse_args()

    if not os.path.exists(args.in_path):
        parser.error("{} is not a valid file path.".format(args.in_image))

    if not args.force and \
            (os.path.exists(args.out_path) or
             os.path.exists(args.bval) or
             os.path.exists(args.bvec)):
        parser.error("Some output files already exists.\n" +
                     "Use -f to force overwriting.")

    data, header = load_fdf(args.in_path)
    save_babel(args.out_path, data, header, args.bval, args.bvec)


if __name__ == "__main__":
    main()
