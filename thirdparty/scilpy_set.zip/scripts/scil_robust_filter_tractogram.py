#!/usr/bin/env python
#  -*- coding: utf-8 -*-

import argparse
import logging

import nibabel as nib
import numpy as np

from scilpy.io.utils import (add_overwrite_arg,
                             assert_inputs_exist,
                             assert_outputs_exists,
                             read_sphere_info_from_scene,
                             read_info_from_mb_bdo,
                             verify_header_compatibility)
from scilpy.segment.streamlines import (filter_grid_roi,
                                        filter_ellipsoid,
                                        filter_cuboid)
from scilpy.tracking.tools import subsample_streamlines


DESCRIPTION = """
    New version of the TrackVis style filtering.
    - Now supports compressed streamlines
    - 3 filtering modes (mask, plane and geometrical shape)
        - 3 types of shape (TrackVis sphere, Mi-Brain ellipsoid or cuboid)
    - Only support *.trk, please convert *.tck for the moment
    - Can filter using any_part, either_end,  both_ends (and --not)
    - The script is now faster (2M streamlines in a typical use-case takes 2 min.)
    WARNING : MI-Brain displays both world coordinates and voxel coordinates,
    TrackVis is in VoxMM, and this script can 'mix' both so it can be confusing

    The default filtering mode is any part, meaning that if any part of a
    streamline touches a ROI, the streamlines will be included in the segmentation.

"""


def _buildArgsParser():
    p = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter,
                                description=DESCRIPTION)

    p.add_argument('in_tractogram', metavar='IN_TRACTOGRAM',
                   help='Path of the input tractogram file (.trk)')
    p.add_argument('out_tractogram', metavar='OUT_TRACTOGRAM',
                   help='Path of the output tractogram file (.trk)')

    seg_group = p.add_mutually_exclusive_group(required=True)
    seg_group.add_argument('--drawn_roi', help='Filename of a hand drawn ROI '
                                               '(.nii or .nii.gz)')
    seg_group.add_argument('--trackvis_sphere', dest='trackvis_sphere', nargs=2,
                           metavar=('SCENE_FILE', 'SPHERE_NAME'),
                           help='Need to provide the TrackVis scene file \n'
                                'and the name of the sphere, '
                                'e.g: dissection.scene "Sphere 1"')
    seg_group.add_argument('--bdo', help='Filename of a bounding object (bdo) '
                                         'file from MI-Brain')

    seg_group.add_argument('--x_plane', type=int,
                           help='Slice number in X, in voxel space')
    seg_group.add_argument('--y_plane', type=int,
                           help='Slice number in Y, in voxel space')
    seg_group.add_argument('--z_plane', type=int,
                           help='Slice number in Z, in voxel space')

    filter_group = p.add_mutually_exclusive_group()
    filter_group.add_argument('--either_end', action='store_true',
                              help='Use either ends of a streamline as '
                                   'a criteria')
    filter_group.add_argument('--both_ends', action='store_true',
                              help='Use both ends of a streamline as '
                                   'a criteria')

    p.add_argument('--not', action='store_true', dest='is_not',
                   help='Invert the filtering')

    p.add_argument('--minL', type=float, default=0,
                   help='Minimal length of a streamline to be selected')
    p.add_argument('--maxL', type=float, default=500,
                   help='Maximal length of a streamline to be selected')

    p.add_argument('--no_empty', action='store_true',
                   help='Do not write file if there is no streamline')
    p.add_argument('-v', action='store_true', dest='verbose',
                   help='Print the filtering information')

    add_overwrite_arg(p)

    return p


def main():
    parser = _buildArgsParser()
    args = parser.parse_args()

    assert_inputs_exist(parser, [args.in_tractogram])
    if not nib.streamlines.TrkFile.is_correct_format(args.in_tractogram):
        parser.error('"{0}" invalid input tractogram'.format(
            args.in_tractogram))
    assert_outputs_exists(parser, args, [args.out_tractogram])

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)

    # Convert bool variable to Dipy friendly string
    filter_type = 'any'
    if args.either_end:
        filter_type = 'either_end'
    elif args.both_ends:
        filter_type = 'both_ends'

    tractogram = nib.streamlines.load(args.in_tractogram)
    if args.drawn_roi:
        img = nib.load(args.drawn_roi)
        mask = img.get_data()
        # Simple check to verify that both datasets voxel space are the same
        if not verify_header_compatibility(img, tractogram):
            parser.error('Headers from the tractogram and the mask are not '
                         'compatible.')

        filtered_streamlines, _ = filter_grid_roi(tractogram, mask, filter_type,
                                                  args.is_not)

    # For every case, the input number must be greater or equal to 0 and below
    #  the dimension, since this is a voxel space operation

    if args.x_plane or args.y_plane or args.z_plane:
        dim = tractogram.header[nib.streamlines.Field.DIMENSIONS]

        mask = np.zeros(dim)
        if args.x_plane:
            if 0 <= args.x_plane < dim[0]:
                mask[args.x_plane, :, :] = 1
            else:
                parser.error('X slice "{0}" is not valid according to the '
                             'tractogram header.'.format(args.x_plane))
        elif args.y_plane:
            if 0 <= args.y_plane < dim[1]:
                mask[:, args.y_plane, :] = 1
            else:
                parser.error('Y slice "{0}" is not valid according to the '
                             'tractogram header.'.format(args.y_plane))
        elif args.z_plane:
            if 0 <= args.z_plane < dim[2]:
                mask[:, :, args.z_plane] = 1
            else:
                parser.error('Z slice "{0}" is not valid according to the '
                             'tractogram header.'.format(args.z_plane))

        filtered_streamlines, _ = filter_grid_roi(tractogram, mask,
                                                  filter_type,
                                                  args.is_not)
    # Both case uses the ellipsoid filtering
    # The radius array will be all equal for a sphere
    geometry = ""
    if args.bdo:
        geometry, radius, center = read_info_from_mb_bdo(args.bdo)

    if geometry == 'Ellipsoid' or args.trackvis_sphere:
        if args.bdo:
            is_in_voxel_space = False
        else:
            center, radius = read_sphere_info_from_scene(
                args.trackvis_sphere[0],
                args.trackvis_sphere[1])
            radius = np.ones((3,)) * radius
            is_in_voxel_space = True

        filtered_streamlines, _ = filter_ellipsoid(tractogram,
                                                   radius,
                                                   center,
                                                   filter_type, args.is_not,
                                                   is_in_voxel_space)

    # Cuboid uses the same reader, but calls a different function
    if geometry == 'Cuboid':
        filtered_streamlines, _ = filter_cuboid(tractogram,
                                                radius,
                                                center,
                                                filter_type, args.is_not)

    # For simplicity, the length filtering is done after (A bit slower, but
    # it is cleaner in the code, because of the --not option it would be
    # confusing to invert the condition on the fly
    filtered_streamlines = subsample_streamlines(filtered_streamlines,
                                                 min_length=args.minL,
                                                 max_length=args.maxL)

    if not filtered_streamlines:
        if args.no_empty:
            logging.debug(
                "The file %s won't be written (0 streamline)", args.out_tractogram)
            return
        else:
            logging.debug("The file %s contains 0 streamline",
                          args.out_tractogram)
    # Right now, only support *.trk file, an reference anatomy would be needed
    # for *.tck
    # Also supporting *.tck would make the script even more complex to test
    # So for now, lets relax about that
    new_tractogram = nib.streamlines.Tractogram(filtered_streamlines,
                                                affine_to_rasmm=np.eye(4))
    trkfile = nib.streamlines.TrkFile(new_tractogram,
                                      header=tractogram.header)
    nib.streamlines.save(trkfile, args.out_tractogram)


if __name__ == "__main__":
    main()
