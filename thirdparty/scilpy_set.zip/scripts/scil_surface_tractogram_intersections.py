#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import logging
import numpy as np

import scilpy.surface.intersection as stools
from scilpy.surface.seed import (
    load_surface_seeds, get_vertices_from_seeds)
from scilpy.io.surface import load_mesh_from_file
from scilpy.io.utils import (
    add_overwrite_arg, assert_inputs_exist, assert_outputs_exists)

# Optionnal package
from dipy.utils.optpkg import optional_package
vtk_u, _, _ = optional_package('trimeshpy.vtk_util')

DESCRIPTION = """
    Script to filter and cut streamlines based on mesh surfaces and ROI.
    Surfaces need to be merged in one with "scil_concatenate_surfaces.py"
        surface_type are generated from "scil_concatenate_surfaces.py"
        surface_mask are generated from "scil_concatenate_map.py"
    """

EPILOG = """
    References:
        [1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
            Surface-enhanced tractography (SET). NeuroImage.
    """


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('surface', help='Input surfaces (.vtk)')

    p.add_argument('tractogram', help='Input tractograms (.vtk or .fib)')

    p.add_argument('surface_type',
                   help='Surface type for each vertex (.npy)')

    p.add_argument('surface_mask',
                   help='Surface mask for each vertex (.npy)')

    p.add_argument('--surface_seeds',
                   help='Tractograms initial seeds (.npz), \n' +
                        'one per surfaces, inputs order is important')

    p.add_argument('--output_intersections',
                   help='intersections map (.npz)')

    p.add_argument('--output_tractogram',
                   help='output tractograms cut from intersection')

    p.add_argument('--only_endpoints', action='store_true',
                   help='only output endpoints intersection')

    """p.add_argument('--output_streamlines_without_intersection', action='store_true',
                   help='also output streamlines with no intersection')"""

    """p.add_argument('--disable_soft_threshold', action='store_true',
                   help='If tractograms cross an surfaces stop immediately, \n'
                   + 'otherwise tractograms stop at the last surfaces \n'
                   + 'or when crossing an outer_surfaces')"""

    add_overwrite_arg(p)
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    assert_inputs_exist(parser, required=[args.tractogram, args.surface,
                                          args.surface_type, args.surface_mask],
                        optional=[args.surface_seeds])

    output_file_list = ([args.output_intersections] + [args.output_tractogram])

    if output_file_list:
        assert_outputs_exists(parser, args, output_file_list)
    else:
        parser.error('No output to be done')


    # Load mesh
    mesh = load_mesh_from_file(args.surface)
    mesh_tree = stools.obbtree_from_polydata(mesh.get_polydata())
    vertices_type = np.load(args.surface_type)
    vertices_mask = np.load(args.surface_mask)

    # Vertices to Triangles mask (true if all triangle' vertices in mask)
    vts_t_mask = vertices_mask[mesh.get_triangles()]
    tri_mask = np.all(vts_t_mask, axis=1)
    print(tri_mask.shape)
    # Vertices to Triangles type (check only the first vertices type)
    tri_type = vertices_type[mesh.get_triangles()[:, 0]]
    print(tri_type.shape)


    # Collisions routine
    cut_streamlines = []
    intersections = []

    streamlines = vtk_u.load_streamlines(args.tractogram)
    if args.surface_seeds:
        tri_idx, tri_coord = load_surface_seeds(args.surface_seeds)
        seeds_vts = get_vertices_from_seeds(mesh, tri_idx, tri_coord)

    for i in xrange(len(streamlines)):
        streamline = streamlines[i]
        nb_pts = len(streamline)

        if nb_pts < 3:
            continue

        # Initialize the list of intersection
        if args.surface_seeds:
            inters = [stools.intersection_from_seed2(tri_idx[i], seeds_vts[i], i)]
        else:
            inters = []

        # Computes all intersections for a streamline
        for seg_id in range(0, nb_pts - 1):
            vtx0 = streamline[seg_id]
            vtx1 = streamline[seg_id + 1]

            # Compute intersections from a segment to all surfaces
            seg_inters = stools.seg_intersect_trees2(vtx0, vtx1, mesh_tree, i,
                                                     seg_id, tri_mask, tri_type)
            seg_inters.sort()

            # Add segment intersections to streamlines intersections
            inters.extend(seg_inters)

        # Generate streamlines' cuts based on intersections
        # remove outside (out of the brain) part,
        cuts = stools.generate_streamline_cuts(inters)

        # Filter streamlines based on cuts
        if args.output_tractogram and cuts:
            cut_streamlines.extend(stools.filter_streamline(streamline, inters, cuts))

        if cuts and args.output_intersections:
            intersections.extend(stools.filter_intersections(inters, cuts, args.only_endpoints))

    if intersections and args.output_intersections:
        # stools.save_intersections_to_txt(args.output_intersections, intersections)
        intersections_arrays = stools.intersections_list_to_arrays(intersections)
        stools.save_surface_intersections(args.output_intersections, *intersections_arrays)

    if cut_streamlines and args.output_tractogram:
        lines_polydata = vtk_u.lines_to_vtk_polydata(cut_streamlines, None)
        vtk_u.save_polydata(lines_polydata, args.output_tractogram, True)


if __name__ == "__main__":
    main()
