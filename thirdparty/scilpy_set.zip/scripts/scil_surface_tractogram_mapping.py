#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import logging

import numpy as np
from scipy.spatial.ckdtree import cKDTree
from scilpy.io.utils import (
    add_overwrite_arg, assert_inputs_exist, assert_outputs_exists)
import scilpy.tractanalysis.todi_util as todi_u

from dipy.utils.optpkg import optional_package
vtk_u, _, _ = optional_package('trimeshpy.vtk_util')


DESCRIPTION = """
Script to filter and cut streamlines based on mesh surfaces and ROI.
"""

EPILOG = """
References:
[1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
    Surface-enhanced tractography (SET). NeuroImage.
"""


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('tractograms', type=str, nargs='+', default=[],
                   help='Input tractograms (.vtk or .fib)')

    p.add_argument('--surfaces', type=str, nargs='+', default=[],
                   required=True, help='Input surfaces (.vtk)')

    # TODO check if needed
    """p.add_argument('--surfaces_masks', type=str, nargs='+', default=[],
                   help='Vertices mask for each input surfaces (.npy)')"""

    p.add_argument('--output_mapping_surf_id', type=str, nargs='+', default=[],
                   help='Tractograms endpoints to closest surface map (.npy)' +
                   'shape=[2, n] | n = number_of_streamlines')

    p.add_argument('--output_mapping_vts_id', type=str, nargs='+', default=[],
                   help='Tractograms endpoints to closest vertices map (.npy)'
                   'shape=[2, n] | n = number_of_streamlines')

    p.add_argument('--output_mapping_info', type=str,
                   help='Surfaces indices linked to input name')

    p.add_argument('--max_distance', type=float, default=4.0,
                   help='Maximum distance (mm) for the closest point search')

    p.add_argument('--processes', type=int, default=-1,
                   help='Number of sub processes to start. [cpu count]')

    add_overwrite_arg(p)
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    assert_inputs_exist(
        parser, required=(args.tractograms + args.surfaces))

    output_file_list = (args.output_mapping_surf_id +
                        args.output_mapping_vts_id +
                        [args.output_mapping_info])

    if output_file_list:
        assert_outputs_exists(parser, args, [], output_file_list)
    else:
        parser.error('No output to be done')

    # Test input
    if (args.output_mapping_surf_id
            and len(args.output_mapping_surf_id) != len(args.tractograms)):
        logging.error("len(output_mapping_surf_id) != len(args.tractograms)")
    if (args.output_mapping_vts_id
            and len(args.output_mapping_vts_id) != len(args.tractograms)):
        logging.error("len(output_mapping_vts_id) != len(args.tractograms)")

    # Load meshes
    surfaces_vertices = []
    surfaces_kdtree = []
    for filename in args.surfaces:
        vertices = vtk_u.get_polydata_vertices(vtk_u.load_polydata(filename))
        surfaces_vertices.append(vertices)
        surfaces_kdtree.append(cKDTree(vertices))

    # Closest points searching
    for tract_id in range(len(args.tractograms)):
        tract_filename = args.tractograms[tract_id]
        streamlines = vtk_u.load_streamlines(tract_filename)
        endpoints = np.vstack(todi_u.streamlines_to_endpoints(streamlines))
        del streamlines

        # Initialize map
        mapping_surface = -np.ones([len(endpoints)], dtype=np.int)
        mapping_vts_indices = -np.ones([len(endpoints)], dtype=np.int)
        mapping_dist = np.full_like(mapping_surface, np.inf, dtype=np.float)
        for i in range(len(surfaces_kdtree)):
            # compute distance with current surface (kd-tree query)
            current_kdtree = surfaces_kdtree[i]
            dist, indices = current_kdtree.query(
                endpoints, k=1, distance_upper_bound=args.max_distance,
                n_jobs=args.processes)

            # distance compared to other surfaces
            new_mapping_dist = dist < mapping_dist
            mapping_surface[new_mapping_dist] = i
            mapping_vts_indices[new_mapping_dist] = indices[new_mapping_dist]
            mapping_dist[new_mapping_dist] = dist[new_mapping_dist]

        # Save mapping (numpy arrays [2,n])
        if args.output_mapping_surf_id:
            np.save(args.output_mapping_surf_id[tract_id],
                    np.reshape(mapping_surface, (2, -1)))

        if args.output_mapping_vts_id:
            np.save(args.output_mapping_vts_id[tract_id],
                    np.reshape(mapping_vts_indices, (2, -1)))

    # Save surfaces info
    if args.output_mapping_info:
        np.savetxt(args.output_mapping_info, args.surfaces, fmt="%s")


if __name__ == "__main__":
    main()
