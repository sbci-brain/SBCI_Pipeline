#! /usr/bin/env python
# -*- coding: utf-8 -*-

"""
Fit Spherical Harmonics to any signal on a sphere, without any modelling.

The sphere is defined by the bvecs / bvals.

Can be used to get a simplified representation of the signal, for
further processing.

NOTE: this script can only be used when all values are on a single shell.
"""

from __future__ import division, print_function

import argparse
import logging

import nibabel as nb
import numpy as np

from dipy.core.gradients import gradient_table
from dipy.io import read_bvals_bvecs

from scilpy.io.utils import (add_overwrite_arg, assert_inputs_exist,
                             assert_outputs_exists, add_force_b0_arg,
                             add_sh_basis_args)
from scilpy.utils.bvec_bval_tools import (normalize_bvecs, is_normalized_bvecs,
                                          check_b0_threshold, identify_shells)
from scilpy.reconst.spherical_signal_to_sh_fit import SphericalSignalToSHFit


def buildArgsParser():

    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('input',
                   help='Path of the input signal defined on a sphere.')

    p.add_argument('bvals',
                   help='Path of the bvals file, in FSL format.')

    p.add_argument('bvecs',
                   help='Path of the bvecs file, in FSL format.')

    p.add_argument('output_sh',
                   help='Output filename for the spherical harmonics ' +
                        'fit to the signal.')

    p.add_argument('--sh_order', default=4, type=int,
                   help='Spherical harmonics order. Must be a positive even ' +
                        'number. [%(default)s]')

    add_sh_basis_args(p)

    p.add_argument('--smooth', type=float, default='0.006',
                   help='Smoothing factor. [%(default)s]')

    p.add_argument('--mask',
                   help='Path to a binary mask.\nOnly data inside the mask ' +
                        'will be used for computations and reconstruction ' +
                        '(Default: None).')

    add_force_b0_arg(p)
    add_overwrite_arg(p)

    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()

    assert_inputs_exist(parser, [args.input, args.bvals, args.bvecs],
                        [args.mask])
    assert_outputs_exists(parser, args, [args.output_sh])

    # Load data
    img = nb.load(args.input)
    data = img.get_data()
    affine = img.get_affine()

    bvals, bvecs = read_bvals_bvecs(args.bvals, args.bvecs)

    if not is_normalized_bvecs(bvecs):
        logging.warning('Your b-vectors do not seem normalized...')
        bvecs = normalize_bvecs(bvecs)

    # Ensure that this is on a single shell.
    shell_values, _ = identify_shells(bvals)
    shell_values.sort()

    if shell_values.shape[0] != 2 or shell_values[0] > 20.:
        raise ValueError("Can only work on single shell signals.")

    check_b0_threshold(args, bvals.min())
    gtab = gradient_table(bvals, bvecs, bvals.min())

    mask = None
    if args.mask is not None:
        mask = nb.load(args.mask).get_data().astype(np.bool)

    mod = SphericalSignalToSHFit(gtab, args.sh_order,
                                 basis_type=args.sh_basis, smooth=args.smooth)
    fit = mod.fit(data, mask=mask)

    nb.save(nb.Nifti1Image(fit.shm_coeff.astype(np.float32), affine),
            args.output_sh)


if __name__ == "__main__":
    main()
