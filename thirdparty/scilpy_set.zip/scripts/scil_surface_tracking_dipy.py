#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division

import argparse
from dipy.core.sphere import HemiSphere
from dipy.data import SPHERE_FILES, get_sphere
from dipy.direction import (
    DeterministicMaximumDirectionGetter, ProbabilisticDirectionGetter)
from dipy.tracking.local import BinaryTissueClassifier, LocalTracking
from dipy.tracking.streamlinespeed import compress_streamlines
import nibabel as nib
from nibabel.orientations import aff2axcodes
from nibabel.streamlines import Field
try:
    from nibabel.streamlines.tractogram import LazyTractogram
except ImportError:
    raise ImportError("Unable to import the Nibabel streamline API. "
                      "Nibabel >= v2.1.0 is required")
import numpy as np

from scilpy.io.surface import load_mesh_from_file
from scilpy.io.utils import (
    add_overwrite_arg, assert_inputs_exist,
    assert_outputs_exists, check_surface_seed_support)
from scilpy.surface.seed import (
    closest_initial_dir, get_vertices_from_seeds,
    get_normals_from_seeds, load_surface_seeds)
from scilpy.viz.surface import visualize_mesh_with_seeds

# Optionnal package
from dipy.utils.optpkg import optional_package
vtk_u, _, _ = optional_package('trimeshpy.vtk_util')

DESCRIPTION = """
    Duplicate; Local streamline tractography, with surface seeding.
    See script 'scil_compute_tracking_dipy.py' for details.
    """

EPILOG = """
    References:
        [1] Girard, G., Whittingstall, K., Deriche, R. and Descoteaux, M. 2014
            Towards quantitative connectivity analysis:reducing tractography
            biases. Neuroimage, 98, pp.266-278.
        [2] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
            Surface-enhanced tractography (SET). NeuroImage.
    """

DETERMINISTIC = 'det'
PROBABILISTIC = 'prob'
EUDX = 'eudx'


def _build_arg_parser():
    p = argparse.ArgumentParser(
        description=DESCRIPTION, epilog=EPILOG,
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument('type', choices=[DETERMINISTIC, PROBABILISTIC, EUDX],
                   help='Tracking type (deterministic, probabilistic or EuDX'
                   ' based on fODF peaks)')
    p.add_argument('sh_file', help='Spherical Harmonic file')
    p.add_argument('mask_file',
                   help='Tracking mask. Tracking will stop outside this mask')

    p.add_argument('surface', help='Input surface (Freesurfer or VTK)')
    p.add_argument('surface_seeds',
                   help="surface seeds file (.npz) ['tri_idx', 'tri_coord']")

    p.add_argument('output_file', help='Streamline output file (TRK)')

    deviation_angle_group = p.add_mutually_exclusive_group()
    deviation_angle_group.add_argument(
        '--theta', type=float, default=argparse.SUPPRESS,
        help='Maximum angle between 2 steps. [{}=45.0, {}=20.0, {}=60.0]'
             ''.format(DETERMINISTIC, PROBABILISTIC, EUDX))
    deviation_angle_group.add_argument(
        '--curvature', type=float, default=argparse.SUPPRESS,
        help='Minimum radius of curvature R in mm. Replaces --theta')

    p.add_argument('--step_size', default=0.5, type=float,
                   help='Step size used for tracking')
    p.add_argument(
        '--sphere', choices=sorted(SPHERE_FILES.keys()),
        default='repulsion724',
        help='Set of directions to be used for tracking')
    p.add_argument(
        '--basis', default='fibernav', choices=['mrtrix', 'fibernav'],
        help='Basis used for the spherical harmonic coefficients')
    p.add_argument('--sf_thres', type=float, default=0.1,
                   help='Spherical function relative threshold')
    p.add_argument('--max_len', type=float, default=300,
                   help='Maximum length of a streamline in mm')
    p.add_argument('--compress_streamlines', action='store_true',
                   help='If set, compress streamlines on-the-fly')
    p.add_argument(
        '--tolerance_error', type=float, default=0.1,
        help='Tolerance error in mm. A rule of thumb is to set it to 0.1mm '
             'for deterministic streamlines and 0.2mm for probabilistic '
             'streamlines.')
    p.add_argument('--visualize_surface', action='store_true',
                   help='Visualize surface with seed and normals')
    p.add_argument('--seed', type=int, default=None,
                   help='Random number generator seed')
    add_overwrite_arg(p)
    return p


def main():
    parser = _build_arg_parser()
    args = parser.parse_args()
    for param in ['theta', 'curvature']:
        # Default was removed for consistency.
        if param not in args:
            setattr(args, param, None)

    in_files = [args.sh_file, args.mask_file, args.surface, args.surface_seeds]
    assert_inputs_exist(parser, in_files)
    assert_outputs_exists(parser, args, [args.output_file])
    check_surface_seed_support(parser, args.surface_seeds)

    np.random.seed(args.seed)

    mask_img = nib.load(args.mask_file)
    mask_data = mask_img.get_data()

    # Make sure the mask is isotropic. Else, the strategy used
    # when providing information to dipy (i.e. working as if in voxel space)
    # will not yield correct results.
    fodf_img = nib.load(args.sh_file)
    if not np.allclose(np.mean(fodf_img.header.get_zooms()[:3]),
                       fodf_img.header.get_zooms()[0], atol=1.e-3):
        parser.error("SH file is not isotropic. Tracking is not robust.")

    # Load mesh
    mesh = load_mesh_from_file(args.surface)
    mesh.set_vertices(vtk_u.vtk_to_vox(mesh.get_vertices(), mask_img))

    # Load seeds
    tri_idx, tri_coord = load_surface_seeds(args.surface_seeds)
    seeds_vts = get_vertices_from_seeds(mesh, tri_idx, tri_coord)
    seeds_dir = -1.0 * get_normals_from_seeds(mesh, tri_idx, tri_coord)

    # TODO test
    if args.theta:
        if args.theta <= 0. or args.theta > 90.:
            parser.error('Maximal angle ({}) should be between 0 '
                         'and 90 degrees.'.format(args.theta))

        max_angle = args.theta
    else:
        if args.algo == DETERMINISTIC:
            max_angle = 45.
        else:
            max_angle = 20.

    tracking_sphere = HemiSphere.from_sphere(get_sphere(args.sphere))

    if args.type == DETERMINISTIC:
        dgklass = DeterministicMaximumDirectionGetter
    else:
        dgklass = ProbabilisticDirectionGetter

    dg = dgklass.from_shcoeff(
        fodf_img.get_data().astype(np.double),
        max_angle=max_angle,
        sphere=tracking_sphere,
        basis_type=args.basis,
        pmf_threshold=args.sf_thres)
    # dg = _get_direction_getter(args, mask_data)
    #seeds_dir = closest_initial_dir(dg, seeds_vts, seeds_dir)

    # Visualize normal orientation for debug (flip)
    if args.visualize_surface:
        visualize_mesh_with_seeds(mesh, tri_idx, tri_coord)

    # Step size and voxel
    voxel_size = fodf_img.header.get_zooms()[0]
    scaled_max_length = args.max_len / voxel_size

    # Tracking is performed in voxel space
    # try:
    streamlines = LocalTracking(
        dg,
        BinaryTissueClassifier(mask_data),
        seeds_vts, np.eye(4),
        step_size=args.step_size,
        maxlen=int(scaled_max_length) + 1,
        fixedstep=True,
        return_all=True,
        unidirectional=True,
        randomize_forward_direction=False,
        initial_directions=seeds_dir[:, np.newaxis, :])
    # except:
    #     print("Temp fix, use G. Girard Branch for unidirectional tracking")
    #     streamlines = LocalTracking(
    #         dg,
    #         BinaryTissueClassifier(mask_data),
    #         seeds_vts, np.eye(4),
    #         step_size=args.step_size,
    #         maxlen=int(scaled_max_length) + 1,
    #         fixedstep=True,
    #         return_all=True)

    if args.compress_streamlines:
        streamlines = (
            compress_streamlines(s, args.tolerance_error)
            for s in streamlines)

    tractogram = LazyTractogram(lambda: streamlines,
                                affine_to_rasmm=mask_img.affine)

    # Header with the affine/shape from mask image
    header = {
        Field.VOXEL_TO_RASMM: mask_img.affine.copy(),
        Field.VOXEL_SIZES: mask_img.header.get_zooms(),
        Field.DIMENSIONS: mask_img.shape,
        Field.VOXEL_ORDER: ''.join(aff2axcodes(mask_img.affine))
    }

    # Use generator to save the streamlines on-the-fly
    nib.streamlines.save(tractogram, args.output_file, header=header)


if __name__ == '__main__':
    main()
