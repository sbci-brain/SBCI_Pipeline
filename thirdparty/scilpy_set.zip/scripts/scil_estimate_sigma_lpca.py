#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Estimate the sigma for the LPCA denoising.
"""

import argparse

from dipy.denoise.pca_noise_estimate import pca_noise_estimate
from dipy.io.gradients import read_bvals_bvecs
from dipy.core.gradients import gradient_table
import nibabel as nib
import numpy as np

from scilpy.io.utils import (add_overwrite_arg, assert_inputs_exist,
                             assert_outputs_exists, add_force_b0_arg)
from scilpy.utils.bvec_bval_tools import check_b0_threshold


def _build_args_parser():
    p = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument('input',
                   help='Path of the DWI')
    p.add_argument('bvals',
                   help='Path of the bvals file, in FSL format.')
    p.add_argument('bvecs',
                   help='Path of the bvecs file, in FSL format.')
    p.add_argument('sigma',
                   help='Output sigma filename. Must be a Numpy file.')

    p.add_argument('--patch_radius', type=int, default=5,
                   help='Patch radius. The cube of patch size ' +
                   '((2 * patch radius + 1)^3)\nmust be greater than ' +
                   'the number of directions. [%(default)s]')
    p.add_argument('--no_bias_correction', action='store_false',
                   help='Don\'t correct the bias due to Rician noise. ' +
                   '[%(default)s]')
    add_force_b0_arg(p)
    add_overwrite_arg(p)

    return p


def main():
    parser = _build_args_parser()
    args = parser.parse_args()

    assert_inputs_exist(parser, [args.input, args.bvals, args.bvecs])
    assert_outputs_exists(parser, args, [args.sigma])

    bvals, bvecs = read_bvals_bvecs(args.bvals, args.bvecs)
    check_b0_threshold(args, bvals.min())

    img = nib.load(args.input)
    dwi = img.get_data()
    correct_bias = args.no_bias_correction

    gtab = gradient_table(bvals, bvecs, b0_threshold=bvals.min())
    sigma = pca_noise_estimate(dwi, gtab, correct_bias=correct_bias,
                               patch_radius=args.patch_radius)

    np.save(args.sigma, sigma)


if __name__ == "__main__":
    main()
