#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Convert a world coordinate from MI-Brain (in LPS) to a
world RAS coordinate.

The MI-Brain LPS coordinate is the one shown in the
"Position: <x_coord, y_coord, z_coord>" field in the bottom right
corner of MI-Brain.
"""

import argparse

import numpy as np

from scilpy.geometry.reference_frames import convert_mibrain_lps_to_world_ras
from scilpy.io.utils import assert_inputs_exist


def build_args_parser():
    p = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter,
        description=__doc__)

    p.add_argument('x_coord', type=float,
                   help='x coordinate as seen in MI-Brain.')
    p.add_argument('y_coord', type=float,
                   help='y coordinate as seen in MI-Brain.')
    p.add_argument('z_coord', type=float,
                   help='z coordinate as seen in MI-Brain.')
    p.add_argument('ref_image',
                   help='name of the reference image.')

    p.add_argument('--not_strict', action='store_false',
                   help='if set, will not check the point to ensure it is '
                        'inside the image boundaries.')

    return p


def main():
    parser = build_args_parser()
    args = parser.parse_args()

    assert_inputs_exist(parser, [args.ref_image])

    point_to_conv = np.array([args.x_coord, args.y_coord, args.z_coord])
    print(convert_mibrain_lps_to_world_ras(point_to_conv, args.ref_image,
                                           args.not_strict))


if __name__ == "__main__":
    main()
