#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Record a video (in .avi or .gif) of a list of bundles or a tractogram. Tumor,
edema and brain masks can be added in options and have specific color and
opacity values. The images must be in Right Anterior Superior (RAS) space.

The video duration, size and format can be modified in options. Moreover, you
can set the number of rotations and the angle step size.

The number of frame per second (fps) is computed as:
    fps = (nb_rotations * 360 / args.step_size) / duration
The number of fps must be greater than 1.
"""

import argparse
import os
import tempfile

from fury import actor
from moviepy import editor
import nibabel as nib
import numpy as np
import PIL
import vtk
from vtk.util.colors import salmon, yellow, grey

from scilpy.io.utils import add_overwrite_arg, \
    assert_inputs_exist, assert_outputs_exists
from scilpy.viz.screenshot import create_marching_cube


def _build_args_parser():
    p = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument('tractograms', nargs='+',
                   help='List tractograms.\n' +
                   'The file format must be supported by Nibabel. When ' +
                   'giving more than one file, all files\nare rendered in ' +
                   'the same video.')
    p.add_argument('output',
                   help='Output filename. The file format must be .avi or .gif')

    p.add_argument('--shuffle_streamlines_coloring', action='store_true',
                   help='Generate a unique color for each tractogram file')
    p.add_argument('--random_seed', type=int,
                   help='Seed for random color generator')

    masks = p.add_argument_group('Masks options')
    masks.add_argument('--brain_image',
                       help='Brain image filename')
    masks.add_argument('--masks', nargs='+',
                       help='Masks filename')
    masks.add_argument('--mask_opacity', type=float, default=0.3,
                       help='Masks opacity, same for every mask')
    masks.add_argument('--tumor',
                       help='Tumor filename')
    masks.add_argument('--edema',
                       help='Edema filename')
    masks.add_argument('--smoothing', type=int,
                       help='Number of smoothing iteration applied on the masks')

    video = p.add_argument_group('Video options')
    video.add_argument('--duration', type=int, default=10,
                       help='Duration of the animation in second')
    video.add_argument('--step_size', type=int, default=1,
                       help='Step size in degree')
    video.add_argument('--nb_rotations', type=int, default=1,
                       help='Number of rotations')
    video.add_argument('--width', default='1000', type=int,
                       help='Width of the output in pixels')
    video.add_argument('--height', default='1000', type=int,
                       help='Height of the output in pixels')

    add_overwrite_arg(p)

    return p


def load_nifti_actor(filename, color, opacity=0.5, smoothing=None):
    img = nib.load(filename)
    data = img.get_data()
    affine = img.affine
    transform_matrix = vtk.vtkMatrix4x4()
    transform_matrix.DeepCopy((
        affine[0][0], affine[0][1], affine[0][2], affine[0][3],
        affine[1][0], affine[1][1], affine[1][2], affine[1][3],
        affine[2][0], affine[2][1], affine[2][2], affine[2][3],
        affine[3][0], affine[3][1], affine[3][2], affine[3][3]))
    actor = create_marching_cube(data, color, opacity,
                                 smoothing_iterations=smoothing,
                                 spacing=img.header.get_zooms())
    actor.SetUserMatrix(transform_matrix)
    return actor


def main():
    parser = _build_args_parser()
    args = parser.parse_args()

    np.random.seed(args.random_seed)

    optionals = [args.tumor, args.edema, args.brain_image]
    if args.masks:
        optionals.extend(args.masks)
    assert_inputs_exist(parser, args.tractograms, optionals)

    output_name = args.output
    _, ext = os.path.splitext(args.output)
    if ext not in [".avi", ".gif"]:
        parser.error("The output format must be in avi or gif format.")

    assert_outputs_exists(parser, args, [output_name])

    if args.duration <= 0:
        parser.error("The duration of the animation must be greater " +
                     "than 0 seconds.")

    if args.step_size <= 0:
        parser.error("The angle step size must be greater than 0 degree.")

    nb_of_screenshots = int(360 / args.step_size)
    fps = int((args.nb_rotations * nb_of_screenshots) / args.duration)
    if fps < 1:
        parser.error("FPS under 1. Please increase the number of rotations, " +
                     "decrease the duration or adjust the step size.")

    renderer = vtk.vtkRenderer()
    renderer.SetBackground(0, 0, 0)
    camera = renderer.GetActiveCamera()
    camera.SetViewUp(0, 0, 1)
    camera.SetPosition(0, 450, 0)

    render_window = vtk.vtkRenderWindow()
    render_window.SetSize(args.width, args.height)
    render_window.SetOffScreenRendering(1)
    render_window.AddRenderer(renderer)

    if args.edema:
        actor_edema = load_nifti_actor(args.edema, salmon, 0.3, args.smoothing)
        renderer.AddActor(actor_edema)

    if args.tumor:
        actor_tumor = load_nifti_actor(args.tumor, yellow, 0.5, args.smoothing)
        renderer.AddActor(actor_tumor)

    if args.masks:
        for mask in args.masks:
            actor_mask = load_nifti_actor(mask, np.random.rand(3), args.mask_opacity,
                                     args.smoothing)
            renderer.AddActor(actor_mask)

    centers = []
    for bundle in args.tractograms:
        tractogram = nib.streamlines.load(bundle)
        streamlines = tractogram.streamlines
        if args.shuffle_streamlines_coloring:
            color = np.random.rand(3)
        else:
            color = None
        streamline_actor = actor.line(streamlines, colors=color, linewidth=0.2)
        renderer.AddActor(streamline_actor)
        centers.append(streamline_actor.GetCenter())

    if args.brain_image:
        actor_t1 = load_nifti_actor(args.brain_image, grey, 0.2, args.smoothing)
        # Change the center if a brain image is given
        center = actor_t1.GetCenter()
        renderer.AddActor(actor_t1)
    else:
        center = np.mean(centers, axis=0)

    transform = vtk.vtkTransform()
    transform.Identity()

    # Create transform to rotate around center
    transform.Translate(center)
    transform.RotateWXYZ(args.step_size, camera.GetViewUp())
    transform.Translate([-1 * x for x in center])

    frame_list = []
    tmp_dir = tempfile.gettempdir()
    for screenshot_id in xrange(nb_of_screenshots):
        new_position = [0, 0, 0]
        new_focal_point = [0, 0, 0]
        # Apply the transform to the camera position and the focal point
        transform.TransformPoint(camera.GetPosition(), new_position)
        transform.TransformPoint(camera.GetFocalPoint(), new_focal_point)

        camera.SetPosition(new_position)
        camera.SetFocalPoint(new_focal_point)

        camera.OrthogonalizeViewUp()
        renderer.ResetCameraClippingRange()

        render_window.Render()
        window_to_image_filter = vtk.vtkWindowToImageFilter()
        window_to_image_filter.SetInput(render_window)
        window_to_image_filter.Update()

        writer = vtk.vtkPNGWriter()

        # Take a screenshot of the current image
        fpath = os.path.join(tmp_dir, "screenshot{}.png".format(screenshot_id))
        writer.SetFileName(fpath)
        writer.SetInputConnection(window_to_image_filter.GetOutputPort())
        writer.Write()

        frame_list.append(fpath)

    # Repeat the frame if more than one rotation is required
    frame_list = np.tile(frame_list, args.nb_rotations)
    # Create the time points
    time_list = list(np.arange(0, args.duration, 1./fps))
    # Match the time points and the frames together
    img_dict = {a: f for a, f in zip(time_list, frame_list)}

    def make_frame(time):
        fpath = img_dict[time]
        image = PIL.Image.open(fpath)
        return np.asarray(image)

    # Create the video
    clip = editor.VideoClip(make_frame, duration=args.duration)
    if ext == ".gif":
        clip.write_gif(args.output, fps=fps, verbose=False,
                       progress_bar=False)
    else:
        clip.write_videofile(args.output, fps=fps, codec='png',
                             verbose=False, progress_bar=False)


if __name__ == "__main__":
    main()
