#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import logging
import numpy as np
import nibabel as nib
from scipy.ndimage import morphology, map_coordinates
from scipy.spatial import KDTree

from scilpy.io.surface import load_mesh_from_file
from scilpy.io.utils import (
    add_overwrite_arg, assert_inputs_exist, assert_outputs_exists)

from dipy.utils.optpkg import optional_package
vtk_u, _, _ = optional_package('trimeshpy.vtk_util')
trimesh_vtk, _, _ = optional_package('trimeshpy.trimesh_vtk')
mcubes, _, _ = optional_package('mcubes')  # github.com/pmneila/PyMCubes


DESCRIPTION = """
Script to generate a surface map from a image'
example : use wmparc.a2009s.nii.gz with some aseg.stats indices
> python se_vol2surf.py s1a1/mask/S1-A1_wmparc.a2009s.nii.gz\\
    -v -index 16  --vox2vtk -opening 2 -smooth 2
"""

EPILOG = """
References:
[1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
    Surface-enhanced tractography (SET). NeuroImage.
"""


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument('surface', help='input volume/mask')

    p.add_argument('volume',
                   help='volume map (or mask)')

    p.add_argument('out_vts_map',
                   help='output mask (npy array) from vts index')

    p.add_argument('--indices', type=int, nargs='+', default=None,
                   help='color only the selected label')

    p.add_argument('--binarize', action='store_true',
                   help='Force values to booleans, use --binarize_value to'
                        ' change default the threshold for scalar \n'
                        'with --indices, all chosen indices are set to True')

    p.add_argument('--binarize_value', type=float, default=0.0,
                   help='Scalar values > binarize_value := True ')

    p.add_argument('--inverse', action='store_true',
                   help='inverse output mask')

    p.add_argument('-v', '--visualize', action='store_true',
                   help='visualize output surface')

    add_overwrite_arg(p)
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    assert_inputs_exist(parser, required=[args.surface, args.volume])
    assert_outputs_exists(parser, args, args.out_vts_map)

    # Load mesh
    mesh = load_mesh_from_file(args.surface)

    # Load volume
    volume_file = args.volume
    volume_nib = nib.load(volume_file)
    volume = volume_nib.get_data()

    # Get vertices in the image space
    vertices = vtk_u.vtk_to_vox(mesh.get_vertices(), volume_nib)

    coord = vertices.T
    vts_values = np.squeeze(map_coordinates(volume, coord,
                                            order=0, mode='constant'))

    if args.binarize:
        vts_mask = np.zeros_like(vts_values)
        if args.indices is not None:
            for i in args.indices:
                vts_mask[vts_values == i] = True
        else:
            vts_mask = vts_values > args.binarize_value
    else:
        vts_mask = vts_values

    if args.inverse:
        vts_mask = ~vts_mask

    np.save(args.out_vts_map, vts_mask)

    # Visualize
    if args.visualize:
        mesh.update_polydata()
        mesh.update_normals()
        if vts_mask.ndim == 1:
            mesh.set_scalars(vts_mask)
        elif vts_mask.shape[1] == 3:
            mesh.set_colors(vts_mask)
        else:
            mesh.set_scalars(vts_mask[:, 0])
        mesh.display()


if __name__ == "__main__":
    main()
