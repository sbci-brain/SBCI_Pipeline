#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Compute the mean Apparent Fiber Density (AFD) and mean Radial fODF (radfODF)
maps along a bundle.

Can be used to generate AFD and radfODF profiles along a bundle.

Correctly handles compressed streamlines.
"""

from __future__ import print_function
import argparse

import nibabel as nb

from scilpy.io.utils import (add_overwrite_arg, add_sh_basis_args,
                             assert_inputs_exist, assert_outputs_exists)
from scilpy.reconst.afd_along_streamlines import afd_map_along_streamlines
from scilpy.io.streamlines import load_trk_in_voxel_space

EPILOG = """
Reference:
    [1] Raffelt, D., Tournier, JD., Rose, S., Ridgway, GR., Henderson, R., 
        Crozier, S., Salvado, O., & Connelly, A. (2012).
        Apparent Fibre Density: a novel measure for the analysis of 
        diffusion-weighted magnetic resonance images. NeuroImage, 59(4), 3976--3994.
"""


def _build_arg_parser():
    parser = argparse.ArgumentParser(
        description=__doc__, epilog=EPILOG,
        formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument(
        'tracts',
        help='Path of the streamlines file, '
             'compatible with the Nibabel streamlines API.')
    parser.add_argument(
        'fodf',
        help='Path of the fODF volume in spherical harmonics (SH).')
    parser.add_argument(
        'afd_mean_map',
        help='Path of the output mean AFD map.')
    parser.add_argument(
        'rd_mean_map',
        help='Path of the output mean radfODF map.')

    parser.add_argument(
        '--length_weighting', action='store_true',
        help='if set, will weigh the AFD values according to segment '
             'lengths. [%(default)s]')

    add_sh_basis_args(parser)
    add_overwrite_arg(parser)
    return parser


def main():
    parser = _build_arg_parser()
    args = parser.parse_args()

    tracts_path = args.tracts
    assert_inputs_exist(parser, [tracts_path, args.fodf])
    assert_outputs_exists(parser, args, [args.afd_mean_map, args.rd_mean_map])

    streamlines = load_trk_in_voxel_space(tracts_path, anat=args.fodf)

    fodf_img = nb.load(args.fodf)

    afd_mean_map, rd_mean_map = afd_map_along_streamlines(
        streamlines, fodf_img,
        args.sh_basis, args.length_weighting)

    nb.Nifti1Image(afd_mean_map.astype('float32'),
                   fodf_img.affine).to_filename(args.afd_mean_map)

    nb.Nifti1Image(rd_mean_map.astype('float32'),
                   fodf_img.affine).to_filename(args.rd_mean_map)


if __name__ == '__main__':
    main()
