#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Script to denoise a DWI with the Local PCA method [1].
"""

import argparse

from dipy.denoise.localpca import localpca
import nibabel as nib
import numpy as np

from scilpy.io.utils import (add_overwrite_arg, assert_inputs_exist,
                             assert_outputs_exists)


def _build_args_parser():
    p = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawTextHelpFormatter,
        epilog="References: [1] Manjón, J. V., Coupé, P., & Buades, A. (2015). "
               "MRI noise estimation and denoising using non-local PCA. "
               "Medical image analysis, 22(1), 35-47.")
    p.add_argument('input',
                   help='Path of the dwi')
    p.add_argument('sigma',
                   help='Path of the sigma file. Must be a Numpy file')
    p.add_argument('output',
                   help='Path of the denoised DWI')

    p.add_argument('--mask',
                   help='Path of a brain mask')
    p.add_argument('--patch_radius', type=int, default=5,
                   help='Patch radius. The cube of patch size ' +
                   '((2 * patch radius + 1)^3)\nmust be greater than ' +
                   'the number of directions. [%(default)s]')
    p.add_argument('--pca_method', default='svd', choices=['svd', 'eig'],
                   help='PCA method to denoise. svd is slower than eig but ' +
                   'more accurate. [%(default)s]')
    p.add_argument('--tau_factor', type=float, default=2.3,
                   help='Threshold of PCA eigenvalues. [%(default)s]')
    add_overwrite_arg(p)

    return p


def main():
    parser = _build_args_parser()
    args = parser.parse_args()

    assert_inputs_exist(parser, [args.input, args.sigma], [args.mask])
    assert_outputs_exists(parser, args, [args.output])

    img = nib.load(args.input)
    dwi = img.get_data()

    sigma = np.load(args.sigma)
    if args.mask:
        mask = nib.load(args.mask).get_data().astype(bool)
        denoised_arr = localpca(dwi, sigma=sigma, mask=mask,
                                patch_radius=args.patch_radius,
                                pca_method=args.pca_method,
                                tau_factor=args.tau_factor)
    else:
        denoised_arr = localpca(dwi, sigma=sigma,
                                patch_radius=args.patch_radius,
                                pca_method=args.pca_method,
                                tau_factor=args.tau_factor)

    nib.save(nib.Nifti1Image(denoised_arr,
                             img.affine, img.header), args.output)


if __name__ == "__main__":
    main()
