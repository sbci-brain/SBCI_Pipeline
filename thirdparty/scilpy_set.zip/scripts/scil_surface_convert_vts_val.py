#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import logging

from nibabel.freesurfer.io import read_annot, read_label, read_morph_data
import numpy as np

from scilpy.io.surface import load_mesh_from_file
from scilpy.io.utils import (add_overwrite_arg,
                             assert_inputs_exist,
                             assert_outputs_exists)


DESCRIPTION = """
Script to load measurement on surfaces surface (mainly civet or Freesurfer)
and save them in numpy format (.npy) for other scil_surface_* scripts.
"""

EPILOG = """
References:
[1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
    Surface-enhanced tractography (SET). NeuroImage.
"""


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('vts_val', help='Input vertices value:\n annot, label, ' 
                   'color, scalar, morph (.txt or Freesurfer format)')

    p.add_argument('out_vts_val', help='Output vertices value in numpy (.npy)')

    p.add_argument('--reference_surface', help='Reference surface to test'
                   'vertices size\n (Freesurfer or supported by VTK)')
    add_overwrite_arg(p)
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    assert_inputs_exist(parser, required=[args.vts_val], 
                        optional=[args.reference_surface])

    assert_outputs_exists(parser, args, [args.out_vts_val])

    input_extension = args.vts_val.split(".")[-1].lower()
    
    mesh = None
    if args.reference_surface:
        mesh = load_mesh_from_file(args.reference_surface)
    
    if input_extension == "txt":
        values = np.loadtxt(args.vts_val)
        
        # test format (data type)
        if values.ndim == 2 and values.shape[1] == 3:
            logging.info("Input is detected as colors")
            if values.max() <= 1.0:
                values * 255
            out_values = values.astype(np.uint8)
                
        elif np.allclose(values, np.round(values)):
            if values.min() >= 0 and values.max() < 2:
                logging.info("Input is detected as boolean")
                out_values = values.astype(np.bool)
            else:
                logging.info("Input is detected as integers")
                out_values = values.astype(np.int)
        else:
            logging.info("Input is detected as scalar")
            out_values = values.astype(np.float)
            
    elif input_extension == "annot":
        [values, _, _] = read_annot(args.vts_val)
        logging.info("Input is detected as Freesurfer annot")
        out_values = values.astype(np.int)
        
    elif input_extension == "label":
        [labeled_vts, scalars] = read_label(args.vts_val, True)
        
        logging.info("Input is detected as Freesurfer label")
        if mesh is None:
            logging.error("Freesurfer label require a reference_surface")
        
        values = np.zeros([mesh.get_nb_vertices()])
        values[labeled_vts] = scalars
        out_values = values.astype(np.float)
    else:
        try:
            # Freesurfer morph do not have a specific extension
            values = read_morph_data(args.vts_val)
            logging.info("Input is detected as Freesurfer morph")
            out_values = values.astype(np.float)
        except:
            logging.error("Format not supported, please provide a .txt file\n" 
                          " or a Freesurfer annot morph or label")
        
    if mesh is not None:
        if len(out_values) != mesh.get_nb_vertices():
            logging.warning("Values array size != surfaces vertices size\n"
                            " only a values per vertex will be save")
            out_values = out_values[:mesh.get_nb_vertices()]
            
    np.save(args.out_vts_val, out_values)


if __name__ == "__main__":
    main()
