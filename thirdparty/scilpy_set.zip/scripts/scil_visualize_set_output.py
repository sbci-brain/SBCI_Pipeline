#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division, print_function

import argparse
import logging

from fury import window, actor
import numpy as np

from scilpy.io.surface import load_mesh_from_file
from scilpy.io.utils import assert_inputs_exist
from scilpy.surface.seed import (
    load_surface_seeds, get_vertices_from_seeds, get_normals_from_seeds)
import scilpy.surface.intersection as stools

import trimeshpy.vtk_util as vtk_u
from trimeshpy.trimesh_vtk import TriMesh_Vtk
from scipy.sparse import identity
vtk = vtk_u.import_vtk()

from matplotlib import cm


DESCRIPTION = """
Script to visualize surface seeds, intersections or density
    generated from 'scil_surface_seed.py', 'scil_surface_tractogram_filtering.py' and / or
    'scil_surface_intersections_density.py' 
    
    Using "surfaces_id" is really useful for SET Nextflow debugging:
    
>>> scil_visualize_set_output.py D__Surface_Flow/*flow*.vtk \\
        --surface_seeds F__Surface_Enhanced_Tractography/*seeds_0001_i0000.npz \\
        --intersections G__Concatenate_Intersection/*set_c_filtered.npz \\
        --triangle_scalars H__Compute_Surface_Density/*set_density.npy \\
        --surfaces_id B__Concatenate_Surface/*surfaces_type.npy \\
        --indices 1 2  --normalize_l1_to 1000000 --scalar_max 10
"""

EPILOG = """
References:
[1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
    Surface-enhanced tractography (SET). NeuroImage.
"""

REMOVED_INDICES = np.iinfo(np.int32).max


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('surface',
                   help='Input surface (Freesurfer or supported by VTK)')

    group = p.add_mutually_exclusive_group()
    group.add_argument('--triangle_scalars',
                       help='Surface density per triangle map (.npy)')
    group.add_argument('--vts_scalars',
                       help='Surface density per vertices map (.npy)')
    group.add_argument('--vts_label', help='Input vertices label')
    group.add_argument('--vts_color', help='Input vertices color')
    group.add_argument('--image_mask', help='Input image mask')

    p.add_argument('--scalar_min', type=float, default=None,
                   help="Density min")
    p.add_argument('--scalar_max', type=float, default=None,
                   help="Density max")

    factor = p.add_mutually_exclusive_group()
    factor.add_argument('--normalize_l1_to', type=float,
                        help="Normalized the density; to sum to the given number")
    factor.add_argument('--scalar_factor', type=float,
                        help="scaling_factor for the density or other metric")

    p.add_argument('--scalar_smoothing', type=int, default=0,
                   help="Surface density per triangle map (.npy) [%(default)s]")
    p.add_argument('--scalar_colormap', default='jet',
                   help="to rgb colormap used from matplotlib [%(default)s]")

    p.add_argument('--scalar_area_normalized', action='store_true',
                   help="Surface density per triangle area")

    # Seeds Options
    p.add_argument('--surface_seeds', nargs='+', default=[],
                   help="Surface seeds file (.npz) ['tri_idx', 'tri_coord']")

    p.add_argument('--seeds_color', type=float, nargs='+', default=(0, 0, 0),
                   help="Stating point color ")
    p.add_argument('--seeds_size', type=float, default=3,
                   help="Surface seeds point size [%(default)s]")
    p.add_argument('-n', '--normals', type=float, default=None,
                   help="Display seeds normal (with chosen length).")

    # Intersections Options
    p.add_argument('--intersections', nargs='+', default=[],
                   help="Surface intersections file (.npz) (.txt)")

    p.add_argument('--intersections_color0', type=float, nargs='+', default=(1, 1, 1),
                   help="Stating point color ")
    p.add_argument('--intersections_color1', type=float, nargs='+', default=(1, 1, 1),
                   help="Ending point color ")
    p.add_argument('--intersections_size', type=float, default=4,
                   help="Intersections point size [%(default)s]")

    # Display and masking option
    p.add_argument('--background', type=float, nargs='+', default=(0, 0, 0))
    p.add_argument('--surfaces_id',
                   help='Input surfaces id / type (.npy)')
    p.add_argument('--indices', type=int, nargs='+', default=[1],
                   help='Indices surfaces_id')

    p.add_argument('--snapshot', help="take a snapshot of the figure")
    p.add_argument('--size', nargs=2, type=int, default=(1024, 800),
                   help="resolution of the window / snapshot ")

    p.add_argument('--label_id', type=int, nargs='+', default=None,
                   help='Label id')
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    assert_inputs_exist(parser, required=[args.surface],
                        optional=[args.triangle_scalars, args.vts_scalars, args.surfaces_id])

    # Loading files
    full_mesh = load_mesh_from_file(args.surface)
    mesh = load_mesh_from_file(args.surface)

    # Load surfaces map (before removing triangles
    tv_map = mesh.triangle_vertex_map()
    smooth = mesh.laplacian(mesh.edge_map(l2_weighted=True)) + identity(mesh.get_nb_vertices())


    # Initialize vals
    vts_scalar = None
    vts_color = None

    # Load density image, and normalize if needed
    if args.triangle_scalars:
        tri_scalar = np.load(args.triangle_scalars).astype(np.float)
        if args.scalar_area_normalized:
            tri_scalar /= np.asarray(mesh.triangles_area())
        # triangles to vertices
        vts_scalar = np.squeeze(np.asarray(tv_map.T.dot(tri_scalar.T)))

    elif args.vts_scalars:
        vts_scalar = np.load(args.vts_scalars).astype(np.float)
        if args.scalar_area_normalized:
            vts_scalar /= np.asarray(mesh.vertices_area(normalize=True))

    # Load vertices based map
    if args.vts_label:
        # Load labels
        if args.vts_label.split(".")[-1].lower() == "npy":
            vts_label = np.load(args.vts_label)
        else:
            vts_label = np.loadtxt(args.vts_label, dtype=np.int)

        if len(vts_label) != mesh.get_nb_vertices():
            # Resize to vts length
            logging.warning("Warning len(args.vts_label) != nb_vertices()")
            vts_label = vts_label[:mesh.get_nb_vertices()]

        # Generate label color
        vts_color = np.zeros([mesh.get_nb_vertices(), 3])

        if args.label_id is None:
            label_list = np.unique(vts_label[vts_label >= 0])
        else:
            label_list = args.label_id

        for i in label_list:
            vts_color[vts_label == i] = np.random.randint(50, 255, (1, 3))

    elif args.vts_color:
        if args.vts_color.split(".")[-1].lower() == "npy":
            vts_color = np.load(args.vts_color)
        else:
            vts_color = np.loadtxt(args.vts_color, dtype=np.float)

        if len(vts_color) != mesh.get_nb_vertices():
            logging.warning("Warning len(args.vts_color) != nb_vertices() ")
            vts_color = vts_color[:mesh.get_nb_vertices()]

    if args.triangle_scalars or args.vts_scalars:
        if args.normalize_l1_to:
            vts_scalar *= args.normalize_l1_to/np.nansum(vts_scalar)
        if args.scalar_factor:
            vts_scalar *= args.scalar_factor

        if args.scalar_min is None:
            s_min = np.nanmin(vts_scalar)
        else:
            s_min = args.scalar_min

        if args.scalar_max is None:
            s_max = np.nanmax(vts_scalar)
        else:
            s_max = args.scalar_max

        lut = vtk_u.generate_colormap(scale_range=(s_min, s_max))
        colormap = cm.get_cmap(args.scalar_colormap)
        for i in range(256):
            color_i = colormap(i)
            lut.SetTableValue(i, color_i[0], color_i[1], color_i[2], color_i[3])

        for i in range(args.scalar_smoothing):
            vts_scalar = np.squeeze(np.asarray(smooth.dot(vts_scalar)))

    # Load mask / ID map
    if args.surfaces_id:
        ids = np.load(args.surfaces_id)
        vts_mask = np.zeros_like(ids, dtype=np.bool)
        for i in args.indices:
            vts_mask = np.logical_or(vts_mask, ids == i)

        tri_mask = np.any(vts_mask[mesh.get_triangles()], axis=1)
        new_tri = mesh.get_triangles()[tri_mask]
        mesh = TriMesh_Vtk(new_tri, mesh.get_vertices(), assert_args=False)
    else:
        tri_mask = np.ones(mesh.get_nb_triangles(), dtype=np.bool)
        mesh = full_mesh

    # Scene
    scene = window.Scene()

    # Density maps actors
    if vts_scalar is not None:
        mesh.set_scalars(vts_scalar, lut)

        scalar_bar = vtk.vtkScalarBarActor()
        scalar_bar.SetTitle("Density")
        scalar_bar.SetLookupTable(lut)
        scalar_bar.SetNumberOfLabels(6)
        scene.add(scalar_bar)
    elif vts_color is not None:
        mesh.set_colors(vts_color)

    # Intersections maps actors
    for intersections in args.intersections:
        # Load intersections
        if intersections.split(".")[-1].lower() == "npz":
            coll_arrays = stools.load_surface_intersections(intersections)
        else:
            coll_list = stools.load_intersections_from_txt(intersections)
            coll_arrays = stools.intersections_list_to_arrays(coll_list)

        # add intersections to display
        dsize = args.intersections_size
        scene.add(actor.dots(coll_arrays[2][tri_mask[coll_arrays[1]]], color=args.intersections_color0, dot_size=dsize))
        scene.add(actor.dots(coll_arrays[5][tri_mask[coll_arrays[4]]], color=args.intersections_color1, dot_size=dsize))

    # Seeds maps actors
    for seeds_file in args.surface_seeds:
        tri_idx, tri_coord = load_surface_seeds(seeds_file)
        tri_idx_mask = tri_mask[tri_idx]

        tri_idx = tri_idx[tri_idx_mask]
        tri_coord = tri_coord[tri_idx_mask]

        seeds_vts = get_vertices_from_seeds(full_mesh, tri_idx, tri_coord)
        scene.add(actor.dots(seeds_vts, color=args.seeds_color, dot_size=args.seeds_size))

        if args.normals is not None:
            normals = get_normals_from_seeds(full_mesh, tri_idx, tri_coord)

            lines1 = np.tile(seeds_vts[:, np.newaxis, :], (1, 2, 1))
            lines2 = np.tile(seeds_vts[:, np.newaxis, :], (1, 2, 1))
            lines1[:, 0] -= normals * args.normals
            lines2[:, 1] += normals * args.normals

            scene.add(actor.line(lines1, colors=(1, 0, 0)))
            scene.add(actor.line(lines2, colors=(0, 0, 1)))

    scene.add(mesh.get_vtk_actor())
    scene.set_camera(position=(1,0,0), view_up=(0, 0, 1))
    scene.background(args.background)

    scene.ResetCamera()

    if args.snapshot:
        window.snapshot(scene, args.snapshot, size=args.size, offscreen=True,
                        order_transparent=True, max_peels=100)
    else:
        window.show(scene, size=args.size, order_transparent=True, max_peels=100)


if __name__ == "__main__":
    main()
