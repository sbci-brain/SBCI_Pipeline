#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse

from scilpy.io.surface import load_mesh_from_file
from scilpy.io.utils import (add_overwrite_arg,
                             assert_inputs_exist,
                             assert_outputs_exists)


DESCRIPTION = """
Script to convert surfaces (vtk or freesurfer).
"""

EPILOG = """
References:
[1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
    Surface-enhanced tractography (SET). NeuroImage.
"""


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('surface',
                   help='Input surface (Freesurfer or supported by VTK)')

    p.add_argument('out_surface',
                   help='Output surface (supported by VTK)')

    add_overwrite_arg(p)
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()

    assert_inputs_exist(parser, required=[args.surface])
    assert_outputs_exists(parser, args, [args.out_surface])

    mesh = load_mesh_from_file(args.surface)
    mesh.save(args.out_surface)


if __name__ == "__main__":
    main()
