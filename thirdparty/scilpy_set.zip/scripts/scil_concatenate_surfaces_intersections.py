#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse

import numpy as np
from dipy.utils.optpkg import optional_package

import scilpy.surface.intersection as stools
from scilpy.io.utils import (add_overwrite_arg,
                             assert_inputs_exist,
                             assert_outputs_exists)

trimeshpy, have_trimeshpy, _ = optional_package('trimeshpy')


DESCRIPTION = """
Script to concatenate surfaces together in a single file (vtk or freesurfer).
"""

EPILOG = """
References:
[1] St-Onge, E., Daducci, A., Girard, G. and Descoteaux, M. 2018.
    Surface-enhanced tractography (SET). NeuroImage.
"""


def buildArgsParser():
    p = argparse.ArgumentParser(description=DESCRIPTION, epilog=EPILOG,
                                formatter_class=argparse.RawTextHelpFormatter)

    p.add_argument('surface_intersections', nargs='+',
                   help="Surface intersections files (.npz) (.txt)")

    p.add_argument('--output_intersections', required=True,
                   help='intersections map (.npz)')

    add_overwrite_arg(p)
    return p


def main():
    parser = buildArgsParser()
    args = parser.parse_args()

    assert_inputs_exist(parser, required=args.surface_intersections)
    assert_outputs_exists(parser, args, [args.output_intersections])

    surf_ids0_list = []
    tri_ids0_list = []
    pts0_list = []
    surf_ids1_list = []
    tri_ids1_list = []
    pts1_list = []

    for intersections in args.surface_intersections:
        # Load intersections
        if intersections.split(".")[-1].lower() == "npz":
            surf_ids0, tri_ids0, pts0, surf_ids1, tri_ids1, pts1 = stools.load_surface_intersections(intersections)
        else:
            coll_list = stools.load_intersections_from_txt(intersections)
            surf_ids0, tri_ids0, pts0, surf_ids1, tri_ids1, pts1 = stools.intersections_list_to_arrays(coll_list)

        surf_ids0_list.append(surf_ids0)
        tri_ids0_list.append(tri_ids0)
        pts0_list.append(pts0)
        surf_ids1_list.append(surf_ids1)
        tri_ids1_list.append(tri_ids1)
        pts1_list.append(pts1)

    stools.save_surface_intersections(args.output_intersections,
                                      np.concatenate(surf_ids0_list),
                                      np.concatenate(tri_ids0_list),
                                      np.concatenate(pts0_list),
                                      np.concatenate(surf_ids1_list),
                                      np.concatenate(tri_ids1_list),
                                      np.concatenate(pts1_list))


if __name__ == "__main__":
    main()
