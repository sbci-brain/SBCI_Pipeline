Using the streamlines endpoints uniformization scripts
------------------------------------------------------

Running on the outputs of RecoBundleX, version 2, of Francois Rheault. 
The following works well on Maggie Roy's bundles. 
Note that the `--swap` option will depend on the orientation of your data (RAS vs LPS). 
In this case, the data was in [1 2 -3] 
This is only an example.

```
scil_uniformize_streamlines_endpoints.py AF_left.trk AF_left_flipped.trk --axis z --swap
scil_uniformize_streamlines_endpoints.py SLF_3_left.trk SLF_3_left_flipped.trk --axis z --swap
# SLF3 really straight. Another little shot in y to be sure
scil_uniformize_streamlines_endpoints.py SLF_3_left_flipped.trk SLF_3_left_flipped_again.trk --axis y --swap
scil_uniformize_streamlines_endpoints.py CG_left.trk CG_left_flipped.trk --axis z --swap
scil_uniformize_streamlines_endpoints.py UF_left.trk UF_left_flipped.trk --axis z --swap
scil_uniformize_streamlines_endpoints.py CST_left.trk CST_left_flipped.trk --axis z --swap
scil_uniformize_streamlines_endpoints.py CR_left.trk CR_left_flipped.trk --axis z --swap
scil_uniformize_streamlines_endpoints.py ICP_left.trk ICP_left_flipped.trk --axis z --swap
scil_uniformize_streamlines_endpoints.py CC_1.trk CC_1_flipped.trk --axis x 
scil_uniformize_streamlines_endpoints.py MCP_left.trk MCP_left_flipped.trk --axis x
scil_uniformize_streamlines_endpoints.py OR_left.trk OR_left_flipped.trk --axis y --swap
scil_uniformize_streamlines_endpoints.py IFOF_left.trk IFOF_left_flipped.trk --axis y --swap
scil_uniformize_streamlines_endpoints.py ILF_left.trk ILF_left_flipped.trk --axis y --swap
```

Notice how the curving bundles are flipped in `z`, 
the straight association bundles in `y`, 
and the commissural bundles in `x`.  
