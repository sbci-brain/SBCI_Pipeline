#!/bin/bash

# COMING....

# scilpy scripts to cover
scil_compute_eap_shore_metrics.py -h
scil_compute_fodf_max_in_ventricles.py -h
scil_compute_fodf_metrics.py -h
scil_compute_qball_metrics.py -h
scil_sharpen_odf.py -h
scil_compute_rgb_from_odf.py -h
scil_convert_4D_rgb_to_3D_rgb.py -h
scil_multiply_rgb_scalar.py -h
