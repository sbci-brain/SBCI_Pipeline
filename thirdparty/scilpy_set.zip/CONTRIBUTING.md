# Contributing to Scilpy

## Workflow

**Scilpy** development uses a branchy workflow based on topic branches. This corresponds to the *Fork & Pull Model*
mentioned in the [GitHub flow guide]. Our collaboration workflow consists of three main steps:

1. Local Development
    - Update
    - Create a Topic
2. Code Review
    - Share a Topic
    - Test a Topic
    - Revise a Topic
3. Integrate Changes
    - Merge a Topic
    - Delete a Topic


## Testing

In order to ensure the health of **Scilpy**, prior to merging a branch, it needs to be checked that tests pass.
There is no CI system in place as of today, so tests **need to be run locally**.

Follow these instructions to run the tests:

1. Make sure `git lfs` is installed on your system:

    ```
    curl -s https://packagecloud.io/install/repositories/github/git-lfs/script.deb.sh | sudo bash
    sudo apt-get install git-lfs
    ```

2. Clone the `scilpy-data` repository: https://bitbucket.org/sciludes/scilpy-data/
3. Set the `SCILPY_TEST_DIR` environment variable to the path where you cloned the repository:

    ```
    export SCILPY_TEST_DIR=PATH/TO/scilpy_data
    ```

4. Create a virtual environment with the exact dependencies in `requirements.txt` and `requirements-git.txt`.
5. While you’re in your virtual environment, at the root of your **Scilpy** directory, run

    ```
    python -m unittest discover -s scripts/tests/
    ```

If your current branch happens to fail in some tests, do the necessary fixes, ensure that tests pass, and re-push the
branch.

If you add a new test to **Scilpy** and provide new data and/or new baselines for them, make sure you use the
`git lfs` extension for versioning large files. Basically, the following steps are required to version the testing
data so that it is managed as a **Git LFS** file:

```
git lfs track ${my_file} # This adds to .gitattributes to let LFS know that it has to do its magic
git add ${my_file}       # Add to notify git that this should be committed
git add .gitattributes   # Add this to keep it around in all copies of the repository
git commit               # As always
git push                 # Git LFS will work its magic
```

The procedure should also be applied when the new data is a text file (i.e. new `bval`or `bvec` files) that is not
*that* large.

You may find further information in the [Git LFS website](https://git-lfs.github.com/).

## Coding style
This is a first draft of the SCIL coding standard for Python. For C++, use the one that is provided on the
[Fibernavigator website].

### Basic principle
Follow [PEP8] as closely as possible. The main point where we can deviate is on the line length: if breaking up the
line to have 80 chars or less would make everything really unreadable, we can be flexible.

### Shebang line
Scripts should start with
```
#!/usr/bin/env python
# -*- coding: utf-8 -*-
```

### Imports
Always use full imports, even if they come from a file in the same subdirectory. Read [Import ordering] for the import
ordering conventions.

### Argument parsing
1. Optional arguments with more than one letter should use the `--` syntax.
2. When the action is the default one (`store`), do not specify `action='store'`.
3. When the action is `store_true`, do not specify that the default is `False`. That’s already the default behavior.
4. When the type is a `string` (which is the default), do not specify `type=str`.
5. Try to have the `help` section on a separate line.
6. The description of the script should be almost at the beginning, between triple double quotes. It can be referenced
in the `ArgumentParser` constructor as `__doc__`. See [scil_compute_dti_metrics.py] for an example.
7. To add the classical `force` argument, use the `add_overwrite_arg` method from `scilpy.io.utils`.

### UX and usability
We aim to provide scripts that are relatively clear and easy to use for non technical users. With this goal in mind:

1. Add basic file existence checks for paths and directories specified as arguments to a script. Telling the user with
a `parser.error` is clearer than a [nibabel] `file not found error`.
2. When possible, use the `assert_inputs_exist` and `assert_outputs_exists` methods from `scilpy.io.utils` for
checking input/output existence.
3. Use `try / catch` blocks for blocks that are possible to handle and may be created by realistic use cases. Else,
let the exception bubble up, and then deal with it when it happens.

### Printing and logging
Instead of using naked prints in the scripts, use Python’s logging facilities. Helps when running lots of scripts, to
direct outputs to various logging mechanisms.


[scil_compute_dti_metrics.py]: scripts/scil_compute_dti_metrics.py

[Fibernavigator website]: https://github.com/scilus/fibernavigator/wiki/Coding-standard
[GitHub flow guide]: https://guides.github.com/introduction/flow/index.html
[Import ordering]:  https://www.python.org/dev/peps/pep-0008/#imports
[nibabel]: http://nipy.org/nibabel/
[PEP8]: https://www.python.org/dev/peps/pep-0008/
